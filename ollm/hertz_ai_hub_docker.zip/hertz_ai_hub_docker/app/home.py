import os
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
import streamlit as st
from streamlit_card import card
import streamlit_antd_components as sac
from utils import image_data, update_return_home, update_ollama_status, hide_footer

hide_footer()
update_return_home()
update_ollama_status()

if not hasattr(st.session_state, "page"):
    st.session_state.page = st.query_params.to_dict().get('page', "Home")

def navigate(page):
    if st.session_state.page != page:
        st.session_state.page = page
        st.rerun()

def show_footer():
    st.markdown("""
    <style>
        .footer {
            position: fixed;
            bottom: 0;
            left: 0;
            width: 100%;
            background-color: #f8f9fa;
            padding: 10px 0;
            text-align: center;
            font-size: 14px;
            color: #6c757d;
        }
    </style>
    <div class="footer">
        Disclaimer: Our platform employs AI for enhanced functionality and user experiences. While efforts are made to ensure accuracy, users should be aware that AI-generated content may contain errors or biases, and discretion is advised.
    </div>
""", unsafe_allow_html=True)

def draw_header(icon, text): return sac.divider(
    label=f"""### {text}""", icon=icon, align='center', size='sm', color='gray')

def show():
    if st.session_state.page == "Home":
        st.markdown("<h1 style='text-align: center; font-size: 4em;'>Hertz AI Central</h1><p>&nbsp;<p>&nbsp;", unsafe_allow_html=True)
        draw_header("1-circle", "Data Analyst/Steward Tools")
        top_row = st.columns([1])
        with top_row[0]:
            card(
                title="Datalake Assistant",
                text="Automated data discovery, annotations, and insights from data assets",
                image=image_data("images/catalog.jpg"),
                on_click=lambda: navigate("catalog"),
                key='card1',
                styles={
                        "card": {
                        "width": "100%",
                        "height": "350px",
                        "border-radius": "20px",
                        "box-shadow": "0 0 10px rgba(200,200,200,0.5)",
                    },
                    "filter": {
                        "background-color": "rgba(0, 0, 0, 0.5)"
                    }
                }
            )
        
        draw_header("2-circle", "Business Analyst Tools")
        mid_row = st.columns([1, 2])
        with mid_row[0]:
            card(
                title="Profiling Service",
                text="Let AI analyze your datasets for insights",
                image=image_data("images/reports.jpg"),
                on_click=lambda: navigate("profile"),
                key='card3',
                styles={
                        "card": {
                        "width": "100%",
                        "height": "350px",
                        "border-radius": "20px",
                        "box-shadow": "0 0 10px rgba(200,200,200,0.5)",
                    },
                    "filter": {
                        "background-color": "rgba(0, 0, 0, 0.5)"
                    }
                }
            )
        with mid_row[1]:
            card(
                title="Observability Assistant",
                text="Monitor business KPIs and metrics",
                image=image_data("images/pulse.jpg"),
                on_click=lambda: navigate("trends"),
                key='card4',
                styles={
                        "card": {
                        "width": "100%",
                        "height": "350px",
                        "border-radius": "20px",
                        "box-shadow": "0 0 10px rgba(200,200,200,0.5)",
                    },
                    "filter": {
                        "background-color": "rgba(0, 0, 0, 0.5)"
                    }
                }
            )
    
        draw_header("3-circle", "Developer Tools")
        bottom_row = st.columns([2, 1])
        with bottom_row[0]:
            card(
                title="DevOps Assistant",
                text="From Jira to Kubernetes in hours, not sprints!",
                image=image_data("images/code.jpg"),
                on_click=lambda: navigate("code"),
                key='card5',
                styles={
                        "card": {
                        "width": "100%",
                        "height": "350px",
                        "border-radius": "20px",
                        "box-shadow": "0 0 10px rgba(200,200,200,0.5)",
                    },
                    "filter": {
                        "background-color": "rgba(0, 0, 0, 0.5)"
                    }
                }
            )
        with bottom_row[1]:
            card(
                title="Swift Solutions",
                text="Ideas to Results in minutes, not meetings!",
                image=image_data("images/heatmap.jpg"),
                on_click=lambda: navigate("heatmap"),
                key='card6',
                styles={
                        "card": {
                        "width": "100%",
                        "height": "350px",
                        "border-radius": "20px",
                        "box-shadow": "0 0 10px rgba(200,200,200,0.5)",
                    },
                    "filter": {
                        "background-color": "rgba(0, 0, 0, 0.5)"
                    }
                }
            )

        draw_header("4-circle", "Miscellaneous Tools")
        misc_row = st.columns([1, 1])
        with misc_row[0]:
            card(
                title="Ontology Assistant",
                text="Unstructured language to structured data",
                image=image_data("images/structured.jpg"),
                on_click=lambda: navigate("extraction"),
                key='card7',
                styles={
                        "card": {
                        "width": "100%",
                        "height": "350px",
                        "border-radius": "20px",
                        "box-shadow": "0 0 10px rgba(200,200,200,0.5)",
                    },
                    "filter": {
                        "background-color": "rgba(0, 0, 0, 0.5)"
                    }
                }
            )
        with misc_row[1]:
            card(
                title="Research Assistant",
                text="Kickstart research slides in minutes",
                image=image_data("images/powerpoint.jpg"),
                on_click=lambda: navigate("powerpoint"),
                key='card8',
                styles={
                        "card": {
                        "width": "100%",
                        "height": "350px",
                        "border-radius": "20px",
                        "box-shadow": "0 0 10px rgba(200,200,200,0.5)",
                    },
                    "filter": {
                        "background-color": "rgba(0, 0, 0, 0.5)"
                    }
                }
            )

        last_row = st.columns([1, 1, 1])
        with last_row[0]:
            card(
                title="Spelling Assistant",
                text="Let LLMs proofread your documents",
                image=image_data("images/grammar.jpg"),
                on_click=lambda: navigate("grammar"),
                key='card9',
                styles={
                        "card": {
                        "width": "100%",
                        "height": "350px",
                        "border-radius": "20px",
                        "box-shadow": "0 0 10px rgba(200,200,200,0.5)",
                    },
                    "filter": {
                        "background-color": "rgba(0, 0, 0, 0.5)"
                    }
                }
            )
        with last_row[1]:
            card(
                title="Translation Assistant",
                text="i18n and l10n Information",
                image=image_data("images/spanish.jpg"),
                on_click=lambda: navigate("language"),
                key='card10',
                styles={
                        "card": {
                        "width": "100%",
                        "height": "350px",
                        "border-radius": "20px",
                        "box-shadow": "0 0 10px rgba(200,200,200,0.5)",
                    },
                    "filter": {
                        "background-color": "rgba(0, 0, 0, 0.5)"
                    }
                }
            )
        with last_row[2]:
            card(
                title="Concierge Desk",
                text="Engage in trivial conversations with AI",
                image=image_data("images/process.png"),
                on_click=lambda: navigate("help"),
                key='card11',
                styles={
                        "card": {
                        "width": "100%",
                        "height": "350px",
                        "border-radius": "20px",
                        "box-shadow": "0 0 10px rgba(200,200,200,0.5)",
                    },
                    "filter": {
                        "background-color": "rgba(0, 0, 0, 0.5)"
                    }
                }
            )


    if st.session_state.page != "Home":
        show_footer()

if st.session_state.page == "catalog":
    from sub_pages import catalog_demoable
    catalog_demoable.show()
if st.session_state.page == "profile":
    from sub_pages import profiling_assistant
    profiling_assistant.show()
if st.session_state.page == "trends":
    from sub_pages import trends_assistant
    trends_assistant.show()
if st.session_state.page == "code":
    from sub_pages import coding_assistant
    coding_assistant.show()
if st.session_state.page == "heatmap":
    from sub_pages import heatmap
    heatmap.show()
if st.session_state.page == "extraction":
    from sub_pages import extraction_assistant
    extraction_assistant.show()
if st.session_state.page == "powerpoint":
    from sub_pages import powerpoint_assistant
    powerpoint_assistant.show()
if st.session_state.page == "grammar":
    from sub_pages import spelling_assistant
    spelling_assistant.show()
if st.session_state.page == "language":
    from sub_pages import language_assistant
    language_assistant.show()
if st.session_state.page == "help":
    from sub_pages import helpful_assistant
    helpful_assistant.show()

# Execute the main function
if __name__ == "__main__":
    show()