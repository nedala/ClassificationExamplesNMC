def image_data(image_path):
    import base64
    with open(image_path, "rb") as f:
        data = f.read()
        encoded = base64.b64encode(data)
    data = "data:image/png;base64," + encoded.decode("utf-8")
    return data

def hide_footer():
    import streamlit as st
    # Set sidebar state to false/hidden by default and set page width to wide
    st.set_page_config(
        page_title="Analytics Hub",
        layout="wide",
        initial_sidebar_state="expanded",
        page_icon="favicon.ico",
        menu_items={
            "Get Help": "https://www.hertz.com/rentacar/rental-car-deals/",
            "Report a bug": "mailto:narasimha.edala@hertz.com",
            "About": "https://www.hertz.com/rentacar/rental-car-deals/"
        }
    )
    # Hide footer and hamburger menu
    hide_streamlit_style = """
                <style>
                footer {visibility: hidden;}
                /* Add custom text at the bottom right */
                .custom-footer {
                    position: fixed;
                    right: 15px;
                    top: 40px;
                    z-index: 100;
                    background-color: transparent;
                    color: lightgray;
                    font-size: 16px;
                }
                </style>
                """
    st.markdown(hide_streamlit_style, unsafe_allow_html=True)

import streamlit_antd_components as sac
def draw_header(icon, text): return sac.divider(
    label=f"""#### {text}""", icon=icon, align='center', size='xs', color='gray')

def update_return_home():
    import streamlit as st
    if 'page' in st.session_state and st.session_state.page != "Home":
        try:
            return f"""<a href="/", target="_self">Back to AI Central</a><br/>"""
        finally:
            pass
    else:
        return ""

def get_ollama_url():
    import os
    ollama_host = os.environ.get("OLLAMA_HOST", "http://localhost:11434")
    return ollama_host

def update_ollama_status():
    import os
    import requests
    import streamlit as st
    if not hasattr(st.session_state, "llm_status"):
        st.session_state.llm_status = False
    ollama_host = get_ollama_url()
    # Define the URL for the Ollama health check
    ollama_health_url = f"{ollama_host}"
    # Make an HTTP GET request to the Ollama health endpoint
    ollama_health_response = requests.get(ollama_health_url)
    # Check if the response is successful (status code 200)
    if ollama_health_response.status_code == 200:
        ollama_status = "OK"
        status_icon = "✅"  # Green tick emoji
        st.session_state.llm_status = True
    else:
        ollama_status = "Error"
        status_icon = "❌"  # Red cross emoji
        st.session_state.llm_status = False
    # Display the status icon and status message in the Streamlit sidebar
    st.markdown(f"""<div class="custom-footer">{update_return_home()}</div>""" if update_return_home() else f"""<div class="custom-footer">{status_icon} {ollama_host} {ollama_status}</div>""", unsafe_allow_html=True)