import ast
from contextlib import contextmanager
from datetime import timedelta
import shutil
from sqlalchemy import create_engine
import streamlit as st
import os, json, pandas as pd, time
from .llm_utils import llm_decorator, get_markdown_handler
from .query import seasonal_query
from langchain.chains import LLMChain
from langchain.prompts import PromptTemplate
from langchain.schema.runnable import RunnablePassthrough, RunnableLambda
from datetime import datetime
import numpy as np
from langchain.chains import LLMChain, create_sql_query_chain, RetrievalQA
from langchain.vectorstores import Chroma
from langchain.embeddings import SentenceTransformerEmbeddings
from langchain_core.prompts import PromptTemplate
from langchain_community.utilities import SQLDatabase
from ydata_profiling import ProfileReport
import pmdarima
import sqlparse
import plotly.express as px
try:
    import pyautogui
except:
    pass
from .profiling_assistant import auto_convert_dates_to_datetime, generate_narrative

# Function to capture screenshot
def capture_streamlit_screenshot(output_path):
    try:
        # Capture screenshot using pyautogui
        screenshot = pyautogui.screenshot()

        # Save screenshot to file
        screenshot.save(output_path)
    except:
        pass

if not 'observe' in st.session_state:
    st.session_state.observe = {}
state = st.session_state.observe

@llm_decorator()
def stories_chain(llm, query, **kwargs):
    prompt = PromptTemplate.from_template("""You are given a pandas dataframe (in JSON format) that compares percentage difference between expected performance with actual performance.
You must generate a narrative of your observations from the dataframe in 10 bulleted sentences or less in HTML format enclosed in ``` backticks. Each sentence must represent an observation. Think step by step and be brief. 
You are ONLY allowed to present objective facts; not subjective opinions. You are allowed to skip if you do not have sufficient observations to report. Do not throw "cautionary" callouts: FACTUAL observations only.
You MUST ALWAYS include a reference to the period in your observation. You must also ALWAYS include the the reference to the measure. You are penalized if you do not include a fully specified (month/quarter AND year) reference to the period. Same applies to the measure.
You are NOT allowed to use abstract anaphoric references like "this period", "previous year" etc. Instead, use absolutes like "Q1 2021", "August 30, 2017" etc.
When citing numeric values, use decimals to the nearest 2 decimal places. Similarly use US notations for currency, percentages, dates, and large numbers.
You must respond in HTML format. Your response cannot exceed 450 words. ALWAYS cite a factual measure in your observation/bullet.
Provided Dataframe: 
======
`json
{context}
`
======
                                        
Narrative: ```html
""")
    genie =  prompt | llm
    return genie.invoke({'context':query.reset_index().to_json(orient='records')})

@llm_decorator()
def trends_chain(llm, query, **kwargs):
    prompt = PromptTemplate.from_template("""You are provided a pandas datarow (in JSON format) that compares latest period performance with the historic performance on a percentage basis (and percentage basis ONLY). 
You must generate a narrative of your observations from the dataframe in 4 bulleted sentences or less in HTML format enclosed in ``` backticks. Each sentence must represent an observation. Think step by step and be brief. 
You are helping business analysts to spot any anomalies and outlier observations in the data.
You are ONLY allowed to present objective facts; not subjective opinions.
You are allowed to skip if you do not have sufficient observations to report. Do not throw "cautionary" callouts: FACTUAL observations only.
When citing numeric values, use decimals to the nearest 2 decimal places. Similarly use US notations for currency, percentages, dates, and large numbers.
You must respond in HTML format. Your response cannot exceed 150 words. ALWAYS cite a factual measure in your observation/bullet.
Provided Dataframe: 
======
`json
{context}
`
======

Narrative: ```html
""")
    genie =  prompt | llm
    return genie.invoke({'context':query})

history_current_compare_col = 'Percentage Diff between History and Current'
arima_pred_actual_column = """Percentage Change Between Actual and Predicted Measures"""

@st.cache_data
def analyze_temporal_trend(df, temporal_col, measure_cols, historic_cutover_date, start_date, end_date, temporal_grain='1w', agg_metric='mean', groupby_cols=None):
    # Convert the temporal column to datetime
    if not groupby_cols:
        groupby_cols = ['group']
        df['group'] = 'Observation'
    df[temporal_col] = pd.to_datetime(df[temporal_col])
    # Resample the dataframe to the desired temporal frequency (e.g., daily, weekly)
    df.set_index(temporal_col, inplace=True)
    group_cols = groupby_cols if groupby_cols is not None else []
    df_resampled = df.groupby([pd.Grouper(freq=temporal_grain)] + group_cols).agg({col: agg_metric for col in measure_cols}).reset_index().set_index(temporal_col)
    # Filter the dataframe for the historic and current periods
    df_historic = df_resampled[(df_resampled.index >= pd.to_datetime(start_date)) & (df_resampled.index <= pd.to_datetime(historic_cutover_date))]
    df_current = df_resampled[(df_resampled.index > pd.to_datetime(historic_cutover_date)) & (df_resampled.index < pd.to_datetime(end_date))]
    df_historic.index = pd.to_datetime(df_historic.index)
    df_current.index = pd.to_datetime(df_current.index)
    # Calculate the aggregate measure for the historic and current periods
    if not group_cols:
        historic_agg = df_historic.groupby(group_cols)[measure_cols].agg(agg_metric)
        current_agg = df_current.groupby(group_cols)[measure_cols].agg(agg_metric)
    else:
        historic_agg = df_historic.groupby(group_cols)[measure_cols].agg(agg_metric)
        current_agg = df_current.groupby(group_cols)[measure_cols].agg(agg_metric)
    # Calculate the percentage change between historic and current aggregates
    pct_change = ((current_agg - historic_agg) / historic_agg) * 100
    # Calculate the percentage change between historic and current aggregates
    pct_change = ((current_agg - historic_agg) / historic_agg) * 100
    pct_change = pct_change.round(2)  # Convert to 2 decimal floating point
    pct_change = pct_change.astype(str) + "%"  # Append % symbol
    # Create DataFrames for each measure column with labels
    triplets = pd.concat([historic_agg, current_agg, pct_change], axis=1, keys=['Historic', 'Current', history_current_compare_col])
    figs = []
    for measure_col in measure_cols:
        triplets_flat = triplets.copy()
        triplets_flat.columns = ['_'.join(col).strip() for col in triplets_flat.columns.values]
        triplets_flat = triplets_flat.sort_values(by=f'{history_current_compare_col}_{measure_col}', ascending=False)
        # Plot the flattened DataFrame using Plotly Express
        fig = px.bar(triplets_flat[[f'Historic_{measure_col}', f'Current_{measure_col}']], barmode='group', title=f'Temporal Trend of {measure_col}')
        figs.append(fig)
    for measure_col in measure_cols:
        historic_data = df_resampled[measure_col].copy().drop_duplicates()
        mean = historic_data.mean()
        std_dev = historic_data.std()
        LCL = mean - 3 * std_dev  # Lower Control Limit
        UCL = mean + 3 * std_dev  # Upper Control Limit
        df_data = historic_data.to_frame(measure_col)
        fig = px.bar(df_data, x=df_data.index, y=df_data[measure_col], title=f'Control Chart of {measure_col}')
        fig.update_layout(xaxis_title='Time', yaxis_title=f'{measure_col}')
        # Add LCL and UCL lines
        fig.add_hline(y=LCL, line=dict(color='red', width=2), annotation_text='LCL', annotation_position="top right")
        fig.add_hline(y=mean, line=dict(color='blue', width=2), annotation_text='Mean', annotation_position="top left")
        fig.add_hline(y=UCL, line=dict(color='red', width=2), annotation_text='UCL', annotation_position="bottom right")
        figs.append(fig)
    return triplets, figs

@st.cache_data
def analyze_temporal_trend_arima(df, temporal_col, measure_cols, historic_cutover_date, start_date, end_date, temporal_grain='1w', agg_metric='mean', groupby_cols=None):
    results = pd.DataFrame()
    historic_results = {}
    predicted_results = {}

    # Convert the temporal column to datetime
    df[temporal_col] = pd.to_datetime(df[temporal_col])

    if not groupby_cols:
        groupby_cols = ['group']
        df['group'] = ''

    # Iterate through each measure column
    for measure_col in measure_cols:
        # Group the dataframe by dimensional series and iterate
        groups = df.groupby(groupby_cols)
        for group_name, group_data in groups:
            # Resample the dataframe to the desired temporal frequency (e.g., daily, weekly)
            group_data.set_index(temporal_col, inplace=True)

            # Fill null values with zero
            group_data[measure_col].fillna(0, inplace=True)

            df_resampled = group_data.groupby([pd.Grouper(freq=temporal_grain)]).agg({measure_col: agg_metric})

            df_historic = df_resampled[(df_resampled.index >= pd.to_datetime(start_date)) & (df_resampled.index <= pd.to_datetime(historic_cutover_date))]
            df_current = df_resampled[(df_resampled.index > pd.to_datetime(historic_cutover_date)) & (df_resampled.index < pd.to_datetime(end_date))]

            # Resample the index to a datetime index, not a unix timestamp index
            df_historic.index = pd.to_datetime(df_historic.index)
            df_current.index = pd.to_datetime(df_current.index)

            try:
                # Train an AutoARIMA model for the current measure column
                model = pmdarima.auto_arima(df_historic[measure_col].fillna(0), seasonal=True, stepwise=True, trace=False)

                # Predict values for the current window (outside of historic data)
                predicted_values = model.predict(n_periods=len(df_current))
            except Exception as e:
                st.error(f"ARIMA model failed: {e}")
                predicted_values = np.zeros(len(df_current))

            # Reset the index of actual values to align with predicted values
            actual_values = df_current[measure_col]

            # Calculate percentage change between actual and predicted
            pct_change = ((actual_values - predicted_values) / predicted_values) * 100

            # Create DataFrames for historic and predicted values
            historic_df = df_historic[measure_col].to_frame('Value')
            historic_df['Type'] = 'Historic'
            predicted_df = pd.DataFrame(predicted_values, index=df_current.index, columns=['Value'])
            predicted_df['Type'] = 'Predicted'
            # Concatenate historic and predicted DataFrames
            group_name = group_name[0] if group_name else 'All'
            historic_results[(group_name, measure_col)] = historic_df
            predicted_results[(group_name, measure_col)] = predicted_df

            # Create DataFrame for results
            pdf = pd.DataFrame(zip(actual_values, predicted_values, pct_change), columns=['Actual', 'Predicted', arima_pred_actual_column], index=actual_values.index)
            pdf['Dimensional_Series'] = [group_name for _ in actual_values.index]
            pdf['Measure_Column'] = [measure_col for _ in actual_values.index]
            results = pd.concat([results, pdf])

    return results, historic_results, predicted_results



@llm_decorator()
def get_temporal(llm, df, **kwargs):
    temporal_string = """You are an EXPERT business analyst. You MUST use your analytical skills to analyze the tabular data presented in the context and determine the ONE temporal attribute of the table that can be used to analyze trends in the data.
The temporal attribute must be of coercable into a date, a time, or a datetime data type. We will be using this attribute to measure ToT (day-over-day, week-over-week, month-over-month, quarter-over-quarter, year-over-year) trends in the data.
The tabular information is presented in JSON format (only three rows). You will ONLY respond with the name of the temporal attribute in a single line not to exceed 64 characters.
For example, for tabular info like: '''[{{'sales_date': '2021-01-01', 'sales': 100}}, {{'sales_date': '2021-01-02', 'sales': 200}}, {{'sales_date': '2021-01-03', 'sales': 300}}]''', your response will be ```sales_date```.
If you do not have sufficient information to determine the temporal attribute, you MUST respond with ```None```.
Tabular Information: '''{context}'''
Temporal Attribute:```
"""
    temporal_llm = LLMChain(
        llm=llm,
        prompt=PromptTemplate.from_template(temporal_string),
        verbose=True,
    )
    return temporal_llm.invoke({'context':df.head(3).to_json(orient='records')})['text'].strip().strip('```').strip().upper()

@llm_decorator()
def get_dimensional(llm, df, temporal_attribute, **kwargs):
    temporal_string = """You are an EXPERT business analyst. You MUST use your analytical skills to analyze the tabular data presented in the context and determine an optional set of dimensional attributes in the table that can be used to analyze trends in the data.
The dimensional attributes are usually categorical attributes in the dataset that are aggregated over a temporal attribute.
The tabular information is presented in JSON format (only three rows). Its possible that the dataset may NOT have dimensional attributes. You will ONLY respond with the list of names of the dimensional attributes in a single line as a list not to exceed 6 attributes at most. Its obvious that a temporal attribute cannot ALSO be a dimensional attribute.
For example, for tabular info like: '''[{{'sales_date': '2021-01-01', 'region':'NA', 'sales_rep':'Chris', 'sales': 100}}, {{'sales_date': '2021-01-02', 'region':'SA', 'sales_rep':'Antonio', 'sales': 200}}, {{'sales_date': '2021-01-03', 'region':'NA', 'sales_rep':'Mike', 'sales': 300}}]''' with a temporal attribute as ```sales_date```, your response will be ```['region', 'sales_rep']```.
If you do not have sufficient information to determine the dimensional attribute, you MUST respond with ```[]```.
Tabular Information: '''{context}'''
Temmporal Attribute: ```{temporal_attribute}```
Dimensional Attributes:```
"""
    temporal_llm = LLMChain(
        llm=llm,
        prompt=PromptTemplate.from_template(temporal_string),
        verbose=True,
    )
    return temporal_llm.invoke({'context':df.head(3).to_json(orient='records'), 'temporal_attribute': temporal_attribute})['text'].strip().strip('```').strip().upper()

@llm_decorator()
def get_measures(llm, df, temporal_attribute, dimensional_attributes, **kwargs):
    temporal_string = """You are an EXPERT business analyst. You MUST use your analytical skills to analyze the tabular data presented in the context and determine a list of metric attributes in the table that can be used to analyze temporal trends.
The metrics/measures are usually numerical. We will be using these attributes to study ToT (day-over-day, week-over-week, month-over-month, quarter-over-quarter, year-over-year) trends.
The tabular information is presented in JSON format (only three rows). You will ONLY respond with the list of metrics/measures in a single line not to exceed 64 characters.
For example, for tabular info like: '''[{{'sales_date': '2021-01-01', 'region':'NA', 'sales_rep':'Chris', 'sales': 100}}, {{'sales_date': '2021-01-02', 'region':'SA', 'sales_rep':'Antonio', 'sales': 200}}, {{'sales_date': '2021-01-03', 'region':'NA', 'sales_rep':'Mike', 'sales': 300}}]''' with a temporal attribute as ```sales_date``` and dimensional attributes as ```['sales_rep', 'region']```, your response will be ```['sales']```.
If you do not have sufficient information to determine the measures, you MUST respond with ```[]```.
Tabular Information: '''{context}'''
Temmporal Attribute: ```{temporal_attribute}```
Dimensional Attributes:```{dimensional_attributes}```
Measures:```
"""
    temporal_llm = LLMChain(
        llm=llm,
        prompt=PromptTemplate.from_template(temporal_string),
        verbose=True,
    )
    return temporal_llm.invoke({'context':df.head(3).to_json(orient='records'), 'temporal_attribute': temporal_attribute, 'dimensional_attributes':dimensional_attributes})['text'].strip().strip('```').strip().upper()

@st.cache_data
def query_data(query: str):
    engine = create_engine(st.secrets["databricks_url"])
    # Fetch data
    data = pd.read_sql_query(query, engine)
    data.columns = data.columns.str.upper()
    return data

def send_mail(email_address, attachment_path, subject, body_original=''):
    import base64
    import urllib.parse
    # Function to encode file as Base64
    def encode_file_to_base64(file_path):
        with open(file_path, "rb") as file:
            encoded_string = base64.b64encode(file.read()).decode("utf-8")
        return encoded_string

    # Encode the attachment as Base64
    encoded_attachment = encode_file_to_base64(attachment_path)
    body = f"{body_original}\n\nPlease find the attached file."
    # Email parameters
    subject = subject.replace(" ", "%20")  # Encode spaces in subject
    subject_link = f"mailto:{email_address}?subject={subject}&body={urllib.parse.quote(body).strip()}"
    mailto_link = f"mailto:{email_address}?subject={subject}&body={urllib.parse.quote(body).strip()}"

    # Display a link to open the email client with JavaScript to force open it
    javascript_code = f'''
    <script>
    function openEmailClient() {{
        window.location.href = "{mailto_link}";
    }}
    setTimeout(openEmailClient, 100);
    </script>
    '''
    st.markdown(f"[Open Email Client]({subject_link})", unsafe_allow_html=True)
    st.markdown(javascript_code, unsafe_allow_html=True)

def get_local_narrative(df, genui):
    with genui:
        with st.spinner("Loading..."):
            profile = ProfileReport(df, explorative=True, )
            state['profile_report'] = profile
            if 'profile_report' in state and state['profile_report'] is not None:
                def get_description_set(profile, fieldname, default=""):
                    try:
                        description_set = profile.description_set
                        return description_set['fields'].get(fieldname, default)
                    except:
                        return default
                narrative_animation = st.empty()
                narrative_text = generate_narrative(
                    sample=df.sample(3).to_markdown() if df is not None else "No data available.",
                    summary=df.describe(include='all').to_markdown() if df is not None else "No summary available.",
                    table=get_description_set(state['profile_report'], 'table', ""),
                    correlations=get_description_set(state['profile_report'], 'correlations', ""),
                    missing=get_description_set(state['profile_report'], 'missing', ""),
                    alerts=get_description_set(state['profile_report'], 'alerts', ""),
                    md_output=get_markdown_handler(narrative_animation, "", code=True), stop=["```", "]]]"], timeout=120)
                narrative_animation.markdown(narrative_text)
                report = state['profile_report'].to_html()
                state['profile_report'].to_file("report.html")
                return narrative_text, "report.html"
            else:
                return None, None

def show():
    # Center align the header
    st.header("Observe your business KPIs", divider=True)
    example_query = sqlparse.format(seasonal_query, reindent=True, keyword_case='upper')
    user_query = st.text_area("Enter SQL Query", value=example_query, height=330, help="Enter a SQL query to fetch the data")

    if not hasattr(st.session_state, "datasets"):
        st.session_state.datasets = None
        st.session_state.temporal = None
        st.session_state.dimensional = []
        st.session_state.measures = []

    cols_7 = st.columns(8)
    if cols_7[3].button("Query"):
        if user_query:
            st.session_state.datasets = None
            with st.spinner("Loading..."):
                st.session_state.datasets = query_data(user_query).reset_index(drop=True)
    if cols_7[4].button("Use Sample Data"):
        with st.spinner("Loading..."):
            df = pd.read_csv("data/s_and_p_5_years.csv")
            df = df[df.Name.str.contains("MSFT|AAPL|AMZN|GOOG")]
            st.session_state.datasets = df

    if st.session_state.datasets is not None:
        st.session_state.datasets.columns = st.session_state.datasets.columns.str.upper()
        st.write("Data Preview")
        st.write(st.session_state.datasets.head(5))
        temporal_attribute = get_temporal(st.session_state.datasets, stop=["```"])
        temporal_attribute = temporal_attribute.strip() if temporal_attribute else None
        dimensional_attributes = get_dimensional(st.session_state.datasets, temporal_attribute, stop=["```"])
        measurements = get_measures(st.session_state.datasets, temporal_attribute, dimensional_attributes, stop=["```"])
        st.session_state.temporal = temporal_attribute if temporal_attribute in st.session_state.datasets.columns else None
        st.session_state.dimensional = ast.literal_eval(dimensional_attributes.split("]")[0] + "]") if ']' in dimensional_attributes else []
        st.session_state.measures = ast.literal_eval(measurements.split("]")[0] + "]") if ']' in measurements else []
        st.write(f"AI thinks that temporal attribute is {st.session_state.temporal}")
        st.write(f"AI thinks that dimensional attributes are {st.session_state.dimensional}")
        st.write(f"AI thinks that metric attributes are {st.session_state.measures}")
        
    if st.session_state.datasets is not None:        
        stories_container = st #.container()
        temp, meas, dim = stories_container.columns(3)
        if hasattr(st.session_state, "temporal") and st.session_state.temporal is not None:
            temp.write("Temporal")
            st.session_state.temporal = temp.text_input("Select Temporal Attribute", placeholder=st.session_state.temporal, value=st.session_state.temporal)
        if hasattr(st.session_state, "dimensional") and st.session_state.dimensional is not None:
            dim.write("Dimensional")
            st.session_state.dimensional = dim.multiselect("Select Dimensional Attributes", options=st.session_state.datasets.select_dtypes(exclude='number').columns, default=[col for col in st.session_state.dimensional if col in st.session_state.datasets.select_dtypes(exclude='number').columns] if st.session_state.dimensional else [])
        if hasattr(st.session_state, "measures") and st.session_state.measures is not None:
            meas.write("Measures")
            st.session_state.measures = meas.multiselect("Select Measures", options=st.session_state.datasets.select_dtypes(include='number').columns, default=st.session_state.measures)
        if hasattr(st.session_state, "temporal") and st.session_state.temporal is not None and hasattr(st.session_state, 'datasets') and st.session_state.datasets is not None:
            df = st.session_state.datasets
            temporal_col = st.session_state.temporal
            df[temporal_col] = pd.to_datetime(df[temporal_col]).apply(lambda x: x.date())
            st.write(df[temporal_col].dtype)
            start_date, cut_date = st.slider(
                "Select Historic Window",
                min_value=df[temporal_col].min(),
                max_value=df[temporal_col].max(),
                value=(df[temporal_col].min(), df[temporal_col].max() - timedelta(days=28))
            )
            end_date = df[temporal_col].max()
            st.write("---")
            submit_button = st.button(label='Analyze Emerging Trends', help="Click to analyze latest trends")
            if submit_button:
                md = st.container()
                with md:
                    with st.spinner('Processing...'): #
                        temporal_col = st.session_state.temporal
                        
                        trends, figs = analyze_temporal_trend(st.session_state.datasets.copy(), temporal_col, st.session_state.measures, cut_date, start_date, end_date, groupby_cols=st.session_state.dimensional)
                        state['trends'] = trends
                        stories_container.subheader("Emerging Trends", divider=True)
                        trendcol, trendstories = stories_container.columns(2)
                        trendcol.dataframe(trends.T, use_container_width=True)
                        for fig in figs:
                            trendcol.plotly_chart(fig)
                        for idx, row in trends.reset_index().iterrows():
                            exp = trendstories.expander(f"Dimension {trends.T.columns[idx]}", expanded=True)
                            story_output = exp.empty()
                            story_descriptive_response = trends_chain(row.to_dict(), md_output=get_markdown_handler(story_output, "", code=True), stop=["```", "]]]"]).rstrip('```').lstrip('```').strip()
                            story_output.markdown(story_descriptive_response, unsafe_allow_html=True)
                        
                        stories_container.subheader("Seasonal Trends", divider=True)
                        arima_trends_df, historic_results, predicted_results = analyze_temporal_trend_arima(st.session_state.datasets.copy(), temporal_col, st.session_state.measures, cut_date, start_date, end_date, groupby_cols=st.session_state.dimensional)
                        arima_trends_df['Actual'] = arima_trends_df['Actual'].round()
                        arima_trends_df['Predicted'] = arima_trends_df['Predicted'].round()
                        for group, measure in arima_trends_df[['Dimensional_Series', 'Measure_Column']].drop_duplicates().itertuples(index=False):
                            exp = stories_container.expander(f"Measure: {measure} {group}", expanded=True)
                            datacol, storiescol = exp.columns(2)
                            # Plotting the data using Plotly Express
                            hist = historic_results[(group, measure)]
                            pred = predicted_results[(group, measure)]
                            fig = px.area(pd.concat([hist, pred.round()]), x=hist.index.tolist() + pred.index.tolist(), y='Value',color='Type',
                                        title=f'Historic and Predicted Values of {measure} {("for " + group) if group else ""}',)
                            # Add bar chart for the predicted values
                            fig.add_bar(x=pred.index, y=pred['Value'], name='Predicted', marker_color='rgba(0,0,0,0.8)')
                            datacol.plotly_chart(fig, use_container_width=True)
                            arima_trends = arima_trends_df[(arima_trends_df['Measure_Column'] == measure) & (arima_trends_df['Dimensional_Series'] == group)]
                            selected_rows = arima_trends[(arima_trends[arima_pred_actual_column] >= 5) | (arima_trends[arima_pred_actual_column] <= -5)].reset_index()
                            selected_rows[temporal_col] = pd.to_datetime(selected_rows[temporal_col]).dt.strftime('%Y-%m-%d')
                            selected_rows.set_index(['Dimensional_Series', 'Measure_Column', temporal_col])[arima_pred_actual_column].sort_values(ascending=False).to_frame()
                            stories_df = pd.concat([selected_rows.head(10), selected_rows.tail(10)]).drop_duplicates()
                            df_exp = datacol.container()
                            df_exp.dataframe(stories_df, use_container_width=True)
                            assistant_output = storiescol.empty()
                            stories_df[arima_pred_actual_column] = stories_df[arima_pred_actual_column].round(2).astype(str) + "%"
                            descriptive_response = stories_chain(stories_df, md_output=get_markdown_handler(assistant_output, "", code=True), stop=["```", "]]]"]).rstrip('```').lstrip('```').strip()
                            assistant_output.markdown(descriptive_response, unsafe_allow_html=True)

            # Create a Streamlit button to trigger the process
            with st.form(key='email_form') as form:
                email_address = st.text_input("Email Address", value="narasimha.edala@hertz.com", help="Enter the recipient's email address")
                if st.form_submit_button('Send Email'):
                    output_path = "streamlit_screenshot.png"
                    capture_streamlit_screenshot(output_path)
                    if 'trends' in state and state['trends'] is not None and not state['trends'].empty:
                        triplets = state['trends'].T
                        triplets_flat = triplets.copy()
                        triplets_flat.columns = ['_'.join(col).strip() for col in triplets_flat.columns.values]
                        df_data = auto_convert_dates_to_datetime(triplets_flat)
                        state['processed_file'] = df_data
                        state['profile_report'] = None
                        answer_div = st.empty()
                        narrative, report_path = get_local_narrative(df_data, answer_div)
                        send_mail(email_address, report_path, "Emerging Trends Report", body_original=narrative)
                    else:
                        st.error("Analysis is incomplete. Please complete the analysis before sending the email.")


# Execute the main function
if __name__ == "__main__":
    show()    