import threading
from langchain.llms import Ollama
import requests
from typing import Any, NamedTuple, Optional, List, Iterator
from pygments.lexers import guess_lexer
from langchain.globals import set_llm_cache
import os

def llm_decorator():
    import functools

    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            llm = get_llm(kwargs.get('base_url', os.environ.get('OLLAMA_HOST', "http://localhost:11434")), kwargs.get('model_name', os.environ.get('MODEL_NAME', "neural-chat")), timeout=kwargs.get('timeout', 60), handler=kwargs.get('md_output', None), stop=kwargs.get('stop', None))
            args = (llm,) + args
            try:
                return func(*args, **kwargs)
            except Exception as exc:
                print(exc, flush=True)
                raise exc
            finally:
                llm = None
                del llm
        return wrapper
    return decorator

class CustomOllama(Ollama):
    def __init__(
        self,
        model: str,
        base_url: str = "http://localhost:11434",
        repeat_penalty: float = 1.2,
        temperature: float = 0.01,
        repeat_last_n: int = -1,
        stop: Optional[List[str]] = None,
        callbacks: Optional[List[Any]] = None,
        timeout: int = 30,
        **kwargs: Any,
    ):
        super().__init__(
            model=model,
            base_url=base_url,
            repeat_penalty=repeat_penalty,
            temperature=temperature,
            repeat_last_n=repeat_last_n,
            stop=stop,
            callbacks=callbacks,
            **kwargs,
        )
        self.timeout = timeout
        
    def _create_stream(
        self,
        api_url: str,
        payload: Any,
        stop: Optional[List[str]] = None,
        timeout_seconds: int = None,  # Specify your custom timeout here
        **kwargs: Any,
    ) -> Iterator[str]:
        if self.stop is not None and stop is not None:
            raise ValueError("`stop` found in both the input and default params.")
        elif self.stop is not None:
            stop = self.stop
        elif stop is None:
            stop = ['ASSISTANT:']
        timeout_seconds = timeout_seconds or self.timeout
        params = self._default_params

        for key in self._default_params:
            if key in kwargs:
                params[key] = kwargs[key]

        if "options" in kwargs:
            params["options"] = kwargs["options"]
        else:
            params["options"] = {
                **params["options"],
                "stop": stop,
                **{k: v for k, v in kwargs.items() if k not in self._default_params},
            }
        if payload.get("messages"):
            request_payload = {"messages": payload.get("messages", []), "format":"json", **params}
        else:
            request_payload = {
                "prompt": payload.get("prompt"),
                "format": "json",
                "images": payload.get("images", []),
                **params,
            }
        # Start a timeout thread
        response = None
        try:
            response = requests.post(
                url=api_url,
                headers={
                    "Content-Type": "application/json",
                },
                json=request_payload,
                stream=True,
                timeout=timeout_seconds,  # Use the custom timeout here
            )
        except Exception as e:
            print(e, flush=True)
            raise e

        def _timeout_thread(timeout_seconds: int):
            import time
            time.sleep(timeout_seconds)
            if response:
                response.close()

        timeout_thread = threading.Thread(target=_timeout_thread, args=(timeout_seconds,))
        timeout_thread.setDaemon(True)
        timeout_thread.start()
        class CustomResponseIterator:
            def __init__(self, response):
                self.response = response
                self.response.encoding = "utf-8"
                if response.status_code != 200:
                    if response.status_code == 404:
                        raise Exception(
                            "Ollama call failed with status code 404. "
                            "Maybe your model is not found "
                            f"and you should pull the model with `ollama pull model_name`."
                        )
                    else:
                        optional_detail = response.json().get("error")
                        raise ValueError(
                            f"Ollama call failed with status code {response.status_code}."
                            f" Details: {optional_detail}"
                        )
                self.iter_lines = response.iter_lines(decode_unicode=True)
                self.is_successful = response.status_code == 200

            def __iter__(self):
                return self

            def __next__(self):
                if self.response is None:
                    raise StopIteration
                if not self.is_successful:
                    raise StopIteration

                try:
                    line = next(self.iter_lines) if self.response and self.iter_lines else """{"done": true, "response": ""}"""
                    return line
                except Exception as exc:
                    print(exc, flush=True)
                    self.response.close()
                    self.response = None
                    raise StopIteration
        return CustomResponseIterator(response)

from langchain.cache import InMemoryCache
set_llm_cache(InMemoryCache())

def get_llm(
        base_url, model_name, timeout=30, repeat_penalty=1.25, temperature=0.01, handler=None, stop=None, **kwargs
    ):
    from langchain_core.callbacks.stdout import StdOutCallbackHandler
    llm = CustomOllama(
            model=f"{model_name}",
            base_url=base_url,
            repeat_penalty=repeat_penalty,
            temperature=temperature,
            repeat_last_n=-1,
            stop=stop,
            callbacks=[handler, StdOutCallbackHandler()] if handler else [StdOutCallbackHandler()],
            timeout=timeout,
            num_ctx=4096,
        )
    return llm



import asyncio
import threading, time
from typing import Any, Dict, List, Optional
from uuid import UUID
from langchain.callbacks.base import BaseCallbackHandler
from langchain_core.outputs import LLMResult

# Streamlit markdown progress handler too; receive a streamlit markdown object and update it
class StreamlitMarkdownProgressHandler(BaseCallbackHandler):
    from langchain_community.llms.ollama import _stream_response_to_generation_chunk
    def __init__(self, markdown_object, initial_text="", code=True, **kwargs):
        self.markdown_object = markdown_object
        self.code = code
        self.initial_text = initial_text
        self.lexer = None
        self.finished = False

    def on_llm_start(self, serialized: Dict[str, Any], prompts: List[str], *, run_id: UUID, parent_run_id: UUID = None, tags: List[str] = None, metadata: Dict[str, Any] = None, **kwargs: Any) -> Any:
        self.finished = False
        self.lexers = None
        self.text = self.initial_text
        self.markdown_object.empty()

    def on_llm_new_token(self, token: str, **kwargs) -> None:
        self.text += token
        self.markdown_object.code(f"{self.text.strip().strip('```')}") if self.code else self.markdown_object.markdown(f"{self.text.strip().strip().strip('```')}", unsafe_allow_html=True)

    def on_llm_end(self, response: LLMResult, *, run_id: UUID, parent_run_id: UUID = None, **kwargs: Any) -> Any:
        self.markdown_object.code(f"{self.text.strip().strip().strip('```')}") if self.code else self.markdown_object.markdown(f"{self.text.strip().strip().strip('```')}", unsafe_allow_html=True)
        self.markdown_object.empty()
        self.finished = True
        self.lexer = None

def get_markdown_handler(output, initial_text, code):
    return StreamlitMarkdownProgressHandler(output, initial_text=initial_text, code=code)