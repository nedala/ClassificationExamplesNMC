from datetime import datetime
import streamlit as st
import json
import pandas as pd
from sqlalchemy import create_engine
import pandas as pd
from datetime import datetime
from datetime import timedelta
import folium
from folium import IFrame
from folium.plugins import Fullscreen
import pytz
from folium.plugins import HeatMap, MarkerCluster
# Streamlit app setup
st.markdown(
    """
    <style>
    /* Change font for the body */
    body {
        font-family: 'Montserrat', sans-serif;
    }

    /* Change font for headers */
    h1, h2, h3, h4, h5, h6, p, div, span, label, input, select, textarea, button, a, li, ul, ol, table, th, td {
        font-family: 'Montserrat', sans-serif;
    }
    </style>
    """,
    unsafe_allow_html=True
)

# Custom CSS to style the Help icon
st.markdown(
    """
    <style>
    .help-icon {
        position: fixed;
        bottom: 10px;
        right: 10px;
        background-color: #007bff;
        color: white;
        border-radius: 50%;
        width: 30px;
        height: 30px;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
    }
    .overlay {
        position: fixed;
        z-index: 1;
        bottom: 60px;
        right: 20px;
        border-radius: 5px;
        padding: 10px;
        color: white;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        display: none;
        max-width: 600px;
        transparency: 0.5;
        border-radius: 5px;
        background-color: rgba(0, 0, 0, 0.9);  /* Adjust alpha (transparency) value */
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }
    .help-icon:hover + .overlay {
        display: block;
    }
    </style>
    """,
    unsafe_allow_html=True
)

# Custom "Help" icon and overlay
st.markdown(
    """
    <div class="help-icon">?</div>
    <div class="overlay">
        <p>This app allows you to explore Hertz Rentals near real-time<p>
        <ul>
            <li>Select a date range using the sidebar on the left.</li>
            <li>Select a location to filter the data by using the dropdown menu.</li>
            <li>Select a map type using the dropdown menu.</li>
            <li>Zoom in/out of the map with the scroll-wheel.</li>
            <li>Hover/Click over the markers to see additional details.</li>
            <li>There is layers in the map that you can toggle with layers icon at the top right corner.</li>
            <li>Click on the fullscreen icon at the top right corner to view the map in fullscreen.</li>
            <li>Click on the summary box to hide it.</li>
        </ul>
    </div>
    """,
    unsafe_allow_html=True
)

# List of available tilesets
tilesets = [
    "CartoDB positron",
    "OpenStreetMap",
    "Stamen Terrain",
    "Stamen Toner",
]


@st.cache_data
def query_data(query: str):
    engine = create_engine(st.secrets["databricks_url"])
    # Fetch data
    data = pd.read_sql_query(query, engine)
    return data

# Function to format address, city, and state


def format_address(address):
    parts = [part.strip().title() if len(part) > 3 else part.strip().upper()
             for part in address.split(',') if part.strip()]
    return ', '.join(parts)


def format_city(city):
    return ', '.join([part.strip().title() for part in city.split(',') if part.strip()])


def format_state(state):
    return state.strip().upper()

def show():
    st.sidebar.write("### Date Range")
    # Filter data by date range
    end_date = datetime.now(pytz.timezone('US/Central'))  # Replace with your desired end date

    # Use date_input for date selection with today's date as default
    selected_date = st.sidebar.date_input('Select a date', end_date)

    # Use time_input for time selection with current time as default
    selected_time = st.sidebar.time_input('Select a time', end_date.replace(minute=0, second=0, microsecond=0).time())

    window_hours = st.sidebar.slider(
        'History Window (Hours)', 
        1, 48, 24  # Minimum, Maximum, Default value
    )
    st.sidebar.write("---")

    end_date = datetime.combine(selected_date, selected_time)  
    start_date = end_date - timedelta(hours=window_hours)

    def format_location(item):
        state = item.split(",")[-1].strip()
        return (format_address(','.join(item.split(',')[:-1])) + ", " + format_state(state)) if isinstance(item, str) and ', ' in item else item


    location_query = f"""SELECT DISTINCT CONCAT_WS(', ', INITCAP(RENTRAL_PICKUPADDRESS.Address), INITCAP(RENTRAL_PICKUPADDRESS.City), UPPER(RENTRAL_PICKUPADDRESS.State)) Location, RENTRAL_PICKUPADDRESS.State
        FROM hdp_dev1_us.heatmaps.plot_rental_data
        WHERE DATE(RENTAL_TIME) >= '{start_date}' AND DATE(RENTAL_TIME) <= '{end_date}'"""
    location_options = query_data(
        location_query)["Location"].tolist()
    selected_location = st.sidebar.selectbox(
        "Select Location (Optional)", ["All"] + location_options, format_func=format_location)

    states = sorted(filter(lambda x: bool(x), query_data(
        location_query)["State"].unique().tolist()))
    states.insert(0, "USA")
    selected_state = st.sidebar.selectbox("Filter by State  (Optional)", states)
    selected_tileset = st.sidebar.selectbox("Choose Map Type:", tilesets)


    # Filter data by location if selected
    location_filter = (f"AND CONCAT_WS(', ', INITCAP(RENTRAL_PICKUPADDRESS.Address), INITCAP(RENTRAL_PICKUPADDRESS.City), UPPER(RENTRAL_PICKUPADDRESS.State)) = '{selected_location}'" if selected_location != "All" else "") + \
        (f"AND UPPER(RENTRAL_PICKUPADDRESS.State) = '{selected_state}'" if selected_state != "USA" else "")
    query = f"""
    SELECT INITCAP(First(RENTAL_DETAILS.RENTAL_NAME)) Rental_Name, FIRST(cast(RENTRAL_PICKUPADDRESS.Latitude as float)) LATITUDE,
        FIRST(cast(RENTRAL_PICKUPADDRESS.Longitude as float)) LONGITUDE,
        INITCAP(RENTRAL_PICKUPADDRESS.Address) Address,
        INITCAP(RENTRAL_PICKUPADDRESS.City) City,
        UPPER(RENTRAL_PICKUPADDRESS.State) State,
        CONCAT_WS(', ', COLLECT_LIST(RAXR_RA_NBR)) AGREEMENT_NUMBERS,
        CONCAT_WS(', ', COLLECT_LIST(RENTAL_DETAILS.CDP_NUMBER)) CDP_NUMBERS,
        CONCAT_WS(', ', COLLECT_LIST(RART_RES_ID)) RESERVATION_IDS,
        COUNT(DISTINCT(RAXR_RA_NBR)) as count
    FROM (SELECT DISTINCT(*) FROM hdp_dev1_us.heatmaps.plot_rental_data)
    WHERE cast(RENTRAL_PICKUPADDRESS.Latitude as float) is not null
        and cast(RENTRAL_PICKUPADDRESS.Longitude as float) is not null
        and 
        RENTAL_TIME >= '{start_date}' AND RENTAL_TIME < '{end_date}' { location_filter }
    GROUP BY CONCAT_WS(
            ', ',
            INITCAP(RENTRAL_PICKUPADDRESS.Address),
            INITCAP(RENTRAL_PICKUPADDRESS.City),
            UPPER(RENTRAL_PICKUPADDRESS.State)
        ),
        INITCAP(RENTRAL_PICKUPADDRESS.Address),
        INITCAP(RENTRAL_PICKUPADDRESS.City),
        UPPER(RENTRAL_PICKUPADDRESS.State)
    """

    # Read data into a Pandas DataFrame using the JDBC URL
    df = query_data(query).dropna(subset=["LATITUDE", "LONGITUDE"])
    # Apply formatting to DataFrame
    df["Rental_Name"] = df["Rental_Name"].apply(
        lambda x: format_address(x) if isinstance(x, str) else "")
    df["Address"] = df["Address"].apply(
        lambda x: format_address(x) if isinstance(x, str) else "")
    df["City"] = df["City"].apply(
        lambda x: format_city(x) if isinstance(x, str) else "")
    df["State"] = df["State"].apply(
        lambda x: format_state(x) if isinstance(x, str) else "")

    summary_row = pd.DataFrame([{
        "Address": str(len((df['Address'] + df['City'] + df['State']).unique())) + " addresses",
        "City": str(len(df['City'].unique())) + " cities",
        "State": str(len(df['State'].unique())) + " states",
        "Rentals Total": df["count"].sum()
    }]).T.to_html(header=False, index=True, classes=["table", "table-bordered", "table-hover"])


    if not df.empty:
        # Create a folium map centered at a specific location (average of selected locations)
        center_lat = df["LATITUDE"].mean()
        center_lon = df["LONGITUDE"].mean()

        # Generate heatmap layer
        heat_data = df[["LATITUDE", "LONGITUDE", "count"]]

        st.markdown(
            """
            <style>
            .map-container {
                position: relative;
                width: 100%;
                height: 500px;
            }
            .overlay-box {
                position: absolute;
                bottom: 40px;
                right: 20px;
                padding: 10px;
                background-color: gray;
                transparency: 0.85;
                border-radius: 5px;
                background-color: rgba(0, 0, 0, 0.3);  /* Adjust alpha (transparency) value */
                box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            }
            </style>
            """,
            unsafe_allow_html=True
        )

        # Create a folium map centered at a specific location
        m = folium.Map(location=[center_lat, center_lon],
                    tiles=selected_tileset, zoom_start=4)

        js_function = """
        function(cluster) {
            var childMarkers = cluster.getAllChildMarkers();
            var sum = 0;
            var size = 30;
            var c = ' marker-cluster-';
            for (var i = 0; i < childMarkers.length; i++) {
                sum += childMarkers[i].options.value;
            }
            if (sum > 500) {
                c += 'large';
                size = 80
            } else if (sum > 100) {
                c += 'medium';
                size = 50
            } else {
                c += 'small';
                size = 30
            }
            return L.divIcon({ html: '<div><span>' + sum + '</span></div>', className: 'marker-cluster' + c, iconSize: new L.Point(40,40)});
        }
        """

        # Create a MarkerCluster for clustering markers
        marker_layer = folium.FeatureGroup(name="Clusters", show=True)
        marker_cluster = MarkerCluster(
            options={'maxClusterRadius': 60}, icon_create_function=js_function).add_to(marker_layer)
        # Blue with 70% transparency
        circular_label_color = "rgba(51, 136, 255, 0.7)"
        # Add markers to the MarkerCluster
        for i, row in df.iterrows():
            popup_content = f"""
        <div style='width: 400px; font-family: Montserrat, sans-serif;'>
            <h3 style='margin-bottom: 10px; font-weight: bold; color: gray;'>Reservation Details</h3>
            <p><strong>Name:</strong> {row['Rental_Name']}</p>
            <p><strong>Address:</strong> {row['Address']}, {row['City']}, {row['State']}</p>
            <p><strong>Rentals:</strong> {row['count']}</p>
            <div class='inner-table'>
                <p><strong>Agreement Numbers:</strong></p>
                <div class='scrollable-table'>
                    {pd.DataFrame(zip(row['AGREEMENT_NUMBERS'].split(', '), row['CDP_NUMBERS'].split(', '), row['RESERVATION_IDS'].split(', ')), columns=[
                    'Agreement', 'CDP', 'Reservation']).drop_duplicates(subset='Agreement').reset_index(drop=True).to_html(index=False)}
                </div>
            </div>
        </div>"""
            iframe = IFrame(html=popup_content, width=500, height=300)
            circular_label = folium.DivIcon(
                html=f"<div style='background-color: {circular_label_color}; border-radius: 25%; text-align: center; color: white; width: 30px; height: 30px; line-height: 30px; border: 2px solid rgba(255, 255, 255, 0.7);'>{row['count']}</div>",
                icon_size=(30, 30),
            )
            marker = folium.Marker([row.LATITUDE, row.LONGITUDE], popup=folium.Popup(
                iframe, max_width=800), value=row["count"], icon=circular_label)
            marker.add_to(marker_cluster)

        marker_layer.add_to(m)

        states_layer = folium.FeatureGroup(
            name="State Rental Tooltips", show=True)

        state_rentals = df.groupby("State")["count"].sum().to_frame(
            'Rentals').reset_index()
        choropleth = folium.Choropleth(
            geo_data="./us_states.json",
            name="State Boundaries",
            data=state_rentals,
            columns=["State", "Rentals"],
            key_on="feature.id",
            fill_color="Blues",
            fill_opacity=0.7,
            line_opacity=.1,
            legend_name="Rentals by State",
            highlight=True,
            show=True,
        ).add_to(m)
        states_layer.add_to(m)

        # Custom function to attach tooltips based on GeoJSON feature
        def get_value(feature):
            state_name = feature['id']
            value = state_rentals[state_rentals['State'] == state_name]['Rentals']
            return str(value.values[0] if not value.empty else 0)

        # Load the GeoJSON data
        with open("./us_states.json", 'r') as file:
            geo_json_data = json.load(file)
            # Add rental values to GeoJSON data
            for feature in geo_json_data['features']:
                feature['properties']['Rentals'] = get_value(feature)

        folium.GeoJson(
            geo_json_data,
            style_function=lambda feature: {
                'fillOpacity': 0,  # 0 means transparent
                'weight': 0  # No border
            },
            tooltip=folium.GeoJsonTooltip(
                fields=['name'],
                aliases=['State:'],
                style=(
                    "background-color: white; color: #333333; font-family: arial; font-size: 12px; padding: 10px;"),
                sticky=True
            ),
            highlight_function=lambda x: {'weight': 3, 'color': 'white'},
            name='State Rentals'
        ).add_child(folium.features.GeoJsonTooltip(name="State Rental Detail", fields=["name", "Rentals"], aliases=["State: ", "Rentals: "])).add_to(states_layer)

        heat_map = HeatMap(heat_data, radius=20)
        heatmap_layer = folium.FeatureGroup(name="Heatmap", show=False)
        # # Display the map in Streamlit
        heat_map.add_to(heatmap_layer)
        heatmap_layer.add_to(m)
        folium.raster_layers.TileLayer(
        tiles = 'https://tiles.stadiamaps.com/tiles/alidade_smooth/{z}/{x}/{y}{r}.png',
        attr = '&copy; <a href="https://stadiamaps.com/" target="_blank">Stadia Maps</a>, &copy; <a href="https://openmaptiles.org/" target="_blank">OpenMapTiles</a> &copy; <a href="https://www.openstreetmap.org/about" target="_blank">OpenStreetMap</a> contributors',
        name = "Stadia Maps",
        overlay = True,
        control = True).add_to(m)

        # Streamlit app setup
        folium.LayerControl().add_to(m)
        Fullscreen(
            position='topright',
            title='Fullscreen',
            titleCancel='Exit Fullscreen',
            forceSeparateButton=False
        ).add_to(m)

        map_container = st.empty()
        with map_container:
            st.components.v1.html(m._repr_html_(), height=800)
        overlay_box = st.markdown(
            f"<div class='overlay-box'><h3 align='center'>Summary</h3>{summary_row}</div>", unsafe_allow_html=True)
        st.write("---")
        if True:
            csv = df.to_csv(index=False)
            st.download_button(label="Download CSV", data=csv,
                            file_name="rentals.csv", mime="text/csv")
