from collections import defaultdict
import shutil
import streamlit as st
import os
import json
import pandas as pd
import time
from .llm_utils import get_llm, llm_decorator, get_markdown_handler
import streamlit_antd_components as sac
import pandas as pd
import numpy as np
from langchain_community.chat_message_histories import StreamlitChatMessageHistory
from langchain.memory import ConversationBufferMemory
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnableLambda, RunnablePassthrough

if not 'extract' in st.session_state:
    st.session_state.extract = {}
state = st.session_state.extract

def draw_header(icon, text): return sac.divider(
    label=text, icon=icon, align='center', color='gray')

p_release = """Hertz Team,
 
As we continue to focus on our corporate purpose of “advancing the way the world moves,” it is essential to recognize the pivotal role played by the Technology and Product teams across the organization. As we move forward, we want to align our efforts around three strategic priorities:
 
Data, Analytics, and Data Science
 
Our commitment remains unwavering: to improve data-driven insights and decision-making throughout Hertz.
Shane Garvey and Jeff Lawlor, VP Enterprise Data Analytics, will lead a cross-functional Technology and Product review of this important function to confirm the current work aligns with our 2024 strategic priorities, and the optimal structure and placement of the team.
The current data science team will report to Jeff Lawlor during the completion of this cross-functional review. Current focus and day-to-day activities for the team remain unchanged.
The Hertz Data Platform will continue evolving as the single source of truth for analytics across Hertz, empowering us to achieve our goals.
 

Let’s approach 2024 with optimism, teamwork, and unwavering focus.
 
Tim and Ned
"""

@llm_decorator()
def extract_entities(llm, document, **kwargs):
    template = """Given a large English document, recognize and extract all entities (and ontological relations) in that text. Avoid being repetitive.
Your response must be a JSON list of entities. Each entity has a "name" field, an "attributes" field, and a "relations" field.

Example Input and Output:
    Document: `Hertz, a car rental company, owns Dollar Thrifty Automotive Group. Hertz is based in the USA.`
    Entities Output: ```json
[
    {{
        "name": "Car Rental",
        "attributes": {{
            "type": "industry",
        }},
        "relations": [
        ]
    }},
    {{
        "name": "Hertz",
        "attributes": {{
            "type": "organization",
            "location": "USA",
            "industry": "Car Rental"
        }},
        "relations": [
            {{
                "rel_type": "owns",
                "entity": "Dollar Thrifty Automotive Group"
            }},
            {{
                "rel_type": "belongs_to",
                "entity": "Car Rental"
            }}
        ]
    }},
    {{
        "name": "Dollar Thrifty Automotive Group",
        "attributes": {{
            "type": "organization",
            "industry": "Car Rental"
        }},
        "relations": [
            {{
                "rel_type": "owned by",
                "entity": "Hertz"
            }}
        ]
    }},
]```

Now, parse this document:
Document: ```{document}```
Entities Output: ```json"""
    prompt = ChatPromptTemplate.from_template(template)
    chain = prompt | llm | StrOutputParser()
    return chain.invoke({'document': document}).strip().strip('```').strip()


def show():
    st.markdown(f"<h1 style='text-align: center;'>Entity Knowledge Graph</h1>", unsafe_allow_html=True)
    container = st.container()
    entity_box = container.container()
    extraction_results = container.container()
    with entity_box:
        textbox = st.text_area('Press Release', p_release, height=400)
        cols = st.columns(7)
        extract_btn = cols[3].button('Extract')
        if extract_btn and textbox:
            text_entity_view = entity_box.empty()
            entities = extract_entities(
                textbox, md_output=get_markdown_handler(text_entity_view, "", code=True))
            text_entity_view.code(entities)

# Execute the main function
if __name__ == "__main__":
    show()
