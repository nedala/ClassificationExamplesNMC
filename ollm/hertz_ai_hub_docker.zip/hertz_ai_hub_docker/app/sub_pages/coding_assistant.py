from datetime import datetime
import shutil
import streamlit as st
import streamlit_antd_components as sac
from .llm_utils import StreamlitMarkdownProgressHandler
import pandas as pd
import os
import re
from datetime import datetime
from langchain.chains import LLMChain
import os
from .llm_utils import llm_decorator
from langchain.prompts import PromptTemplate


def generate_repeatable_id(text):
    import hashlib
    return f"artifacts/{hashlib.md5(text.encode('utf-8')).hexdigest().upper()[:8]}"


def normalize_path(path):
    # Replace multiple backslashes or forward slashes with a single os.sep
    normalized_path = re.sub(r'[/\\]+', "/", os.path.normpath(path))
    return os.path.normpath(normalized_path.lstrip("/"))


def path_split_to_dir_file(root_dir, directory, filename):
    head, tail = os.path.split(normalize_path(os.path.join(
        directory, normalize_path(filename.lstrip(directory)))))
    return os.path.split(os.path.join(root_dir, head, tail))


file_string = """You are an EXPERT developer who will design and organize great software application code.
Given a brief description of a story, you will do two things.

    - First, you will -- unless already pre-specified in the story -- determine a programming language that best fulfills the story: YOU MUST NOT MIX PROGRAMMING LANGUAGES. You are NOT allowed to offer multiple options like sbt or gradlew or maven archetypes. Choose ONE best option.

    - Second, you will plan and organize the project into a hierarchical structure of objects (files and folders). You will present the hierarchy of these objects in the form of a single list of tuples in JSON format. Each tuple is a ({{ name of the object }}, {{directory path of the object relative to root dir}}, object type which is either {{file|dir}}, {{ purpose statement of this object in 3 sentences or less }}).

Take a deep breath and reason step-by-step. Assume Linux filesystem with / file separator. Please aim to reduce the hierarchy depth and the number of files and folders.

You will only generate source files and ignore any runtime files like .class or .jar or .zip or .pyc; build files like .gitignore, .dockerignore etc must be ignored too. Hidden objects that begin with a "." like .dockerignore or .git or .idea or .env MUST BE ignored too. You will not generate any binary, non-text, or output content.

For example, story description: `a python hello world program`, your response will be:
```
[("src", "ROOT", "dir", "Python source code"), ("docs", "ROOT", "dir", "Project Documentation"), ("hello_world.py", "ROOT/src", "file", "Print routine for Hello World"), ("requirements.txt", "ROOT/src", "file", "Project dependencies"), ("README.md", "ROOT/docs", "file", "README file for the project")]
```
Make the folder path of all objects relative to the top level directory named ROOT. You ARE NOT ALLOWED to specify directories outside of the top level directory.

ALWAYS quote filenames and directories. Surround the response in ``` backticks.

Story Description: '''{question}'''
Response: 
```
"""
file_prompt = PromptTemplate.from_template(file_string)
readme_string = """You are an EXPERT developer who will design, structure, and write great software application code. 
Given a brief description of a story and a file layout, you will author a README.md file. Assume Linux filesystem with / file separator.
You will respond with the contents of the README.md file ONLY. Respond in markdown format and surround the response in ``` backticks at the start and end. Please be VERY brief and ONLY respond in markdown format to the question.
Deliberate the desscription and add some interpreted markdown to the README.md file.
Description: '''{question}'''
File Layout: '''{file_layout}'''
```README.md
"""
readme_prompt = PromptTemplate.from_template(readme_string)

content_string = """You are an EXPERT programmer who writes great software code. 
Given the description of a requirement, a single file from the hierarchy, and a stated purpose of the file, you MUST generate full contents for the said file (and said file ONLY). 
You will either employ the programming language requested in the question or determine the best programming language for the question: BUT YOU WILL NOT MIX PROGRAMMING LANGUAGES.
Assume Linux filesystem with / file separator. Assume ONE reasonable runtime version such as JDK 11 or Python 3.8 or Node 14 etc, do not be overly generic about runtime versions.
ONLY if necessary, use the file layout for any decisions in authoring the contents of the said file.
Take a deep breath and reason step-by-step. Please DO NOT be repetitive in your response: be EXTREMELY succint and brief.
You will respond with the contents of the file, nothing extra. Surround response in backticks ```.
YOU ARE NOT ALLOWED to produce any extraneous text besides the contents of the requested file: ABSOLUTELY NO EXCEPTIONS.
YOU ARE NOT ALLOWED to produce syntax errors. 
YOU ARE NOT ALLOWED to produce any binary or non-text content. YOUR RESPONSE MUST BE PLAIN TEXT and IT CANNOT EXCEED 10240 CHARACTERS.
YOU ARE NOT allowed to offer multiple options like quicksort vs mergesort vs bubblesort. Choose ONE best option.
Present the contents of the file in the form of a string, preferably in a single line.
Requirement: '''{question}'''
File layout: '''{file_layout}'''
Said File: '''{directory}/{filename}'''
Purpose of the said file: '''{purpose}'''
Contents for '''{directory}/{filename}''':```{filename}
"""
content_prompt = PromptTemplate.from_template(content_string)


def file_llm_chain(llm): return LLMChain(
    llm=llm,
    prompt=file_prompt,
    verbose=True,
)


def readme_llm_chain(llm): return LLMChain(
    llm=llm,
    prompt=readme_prompt,
    verbose=True
)


def content_llm_chain(llm): return LLMChain(
    llm=llm,
    prompt=content_prompt,
    verbose=True,
)


@llm_decorator()
def create_files(llm, root_dir, response, **kwargs):
    # Scan for text that looks like a list of tuples
    text = response['text']
    import ast
    tuples = re.findall(r'\(.*?\)', text)

    def safe_parse(s):
        try:
            return ast.literal_eval(s)
        except:
            return None

    tuples = [y for y in [safe_parse(f"({x})") for x in tuples if x] if y]
    list_of_tuples = [item for item in tuples if len(item) == 4]
    # Create a pandas frame with the list of tuples
    df = pd.DataFrame(list_of_tuples, columns=[
                      'filename', 'directory', 'type', "purpose"], dtype=str)
    df['_fileid'] = df.apply(lambda x: f"{root_dir}/{str(x.name)}", axis=1)
    for idx, row in df[df['type'] == 'file'].iterrows():
        df.to_csv(f'{root_dir}/file_layout.csv', index=False)
        try:
            with st.expander(f"**{row['directory']}** -- **{row['filename']}** -- **{row['purpose']}**"):
                code_artifact = st.empty()
                nkwargs = kwargs.copy()
                nkwargs.update(
                    {'md_output': StreamlitMarkdownProgressHandler(code_artifact)})
                code_response = content_llm_chain(llm).invoke({'question': response['question'], 'file_layout': str(list(set(
                    df[df['type'] == 'file']['filename'].dropna().tolist()))), 'directory': row['directory'], 'filename': row['filename'], 'purpose': row['purpose']}, **nkwargs)
                content = code_response['text'].strip().strip(
                    "```").strip() if code_response else ''
                with open(row['_fileid'], 'w') as f:
                    f.write(content)
                code_artifact.code(content, line_numbers=True)
        except Exception as e:
            st.write(f"Exception creating file {row.filename}: {e}")
    return df


@llm_decorator()
def run_full_chain(llm, root_dir, query, **kwargs):
    try:
        response = file_llm_chain(llm).invoke({'question': query}, **kwargs)
        return create_files(root_dir, response, **kwargs)
    except Exception as e:
        print(f"Error in full_chain for {query}: {e}")


if not 'coding' in st.session_state:
    st.session_state.coding = {}
state = st.session_state.coding

preseeded_questions_list = {
    'Rental Heatmap': 'Create a folium heatmap that shows overlays of rentals, reservations, fleet levels, and workforce levels at various locations in the US for Hertz, a car rental company. The data is in databricks. Date filters and location filters should be added in the sidebar.',
    'Seizure Folio': 'Create a streamlit folium geo heatmap to show car thefts at various US locations. The theft data is in Oracle\'s MYUSER schema, theft_reports table. Add date filters and port filters in the sidebar.',
    'Video Recoloring': 'Develop a streamlit video coloring application using GFPGAN and OpenCV. The application should browse for a grayscale video, process, and emit a colored video file.',
    'ML Flow': 'Build a machine learning pipeline using MLFlow to predict customer churn. The pipeline should include data ingestion, feature engineering, model training, model tracking, and model serving.',
    'Docker Compose': 'Create a docker composition of ElasticSearch and Kibana. The composition should include a volume mount for ElasticSearch and Kibana data. Configure ES_PASSWORD and KIBANA_PASSWORD as `password`',
    'Sales Trends': 'Given a dataset of sales transactions across various regions and products, author Spark SQL to compute weekly average sales across N weeks and generate percentage differential across each week.',
}


def draw_header(icon, text): return sac.divider(
    label=text, icon=icon, align='center', color='gray')


def requirements_step():
    indices = [idx for idx, key in enumerate(preseeded_questions_list.keys(
    )) if key == state.get('preseeded_questions_list', '')]
    state['preseeded_questions_list'] = sac.segmented(
        items=[
            sac.SegmentedItem(label=key) for key in preseeded_questions_list.keys()], label='', align='center', index=indices[0] if indices else 0, key='preseeded_questions_list')
    text_input = st.text_area(label="What is the requirement?", value=preseeded_questions_list.get(
        state['preseeded_questions_list'], state.get('requirement_request', '')))
    cols = st.columns(10)
    if cols[4].button("Magic!"):
        state['requirement_request'] = text_input
    if cols[5].button("Recreate Magic"):
        state['requirement_request'] = text_input
        root_dir = generate_repeatable_id(text_input)
        try:
            shutil.rmtree(root_dir)
        except:
            pass
    state['active_text'] = text_input


def generate_step():
    repo_container = st.container()
    with repo_container:
        if 'requirement_request' in state and state['requirement_request']:
            query = state['requirement_request']
            st.write(f"Requirement: {query}")
            root_dir = generate_repeatable_id(query)
            toc_placeholder = st.container()
            if not os.path.exists(root_dir):
                os.makedirs(root_dir, exist_ok=True)
                toc_display = st.empty()
                toc = run_full_chain(
                    root_dir, query, md_output=StreamlitMarkdownProgressHandler(toc_display))
                if toc is not None:
                    with toc_placeholder.expander("## Repository Structure", expanded=True):
                        st.write(toc, use_container_width=True)
            else:
                df = pd.read_csv(f'{root_dir}/file_layout.csv')
                any_file_missing = any([row['_fileid'] for idx, row in df[df['type'] == 'file'].iterrows() if not os.path.exists(row['_fileid'])])
                if any_file_missing:
                    shutil.rmtree(root_dir)
                    if not os.path.exists(root_dir):
                        os.makedirs(root_dir, exist_ok=True)
                        toc_display = st.empty()
                        toc = run_full_chain(
                            root_dir, query, md_output=StreamlitMarkdownProgressHandler(toc_display))
                        if toc is not None:
                            with toc_placeholder.expander("## Repository Structure", expanded=True):
                                st.write(toc, use_container_width=True)
                for idx, row in df[df['type'] == 'file'].iterrows():
                    with open(row['_fileid'], 'r') as f:
                        content = f.read()
                        with st.expander(f"**{row['directory']}** -- **{row['filename']}** -- **{row['purpose']}**"):
                            code_artifact = st.empty()
                            code_artifact.code(content, line_numbers=True)
                with toc_placeholder.expander("## Repository Structure", expanded=True):
                    st.write(df, use_container_width=True)
                cols = st.columns(8)
                if cols[3].button("Download Repo"):
                    fname = f"{datetime.now().strftime('%Y-%m-%d_%H-%M-%S')}_repository"
                    shutil.make_archive(fname, 'zip', root_dir)
                    zip_file_path = f"{fname}.zip"
                    st.markdown(
                        f'<a href="{zip_file_path}" download="{zip_file_path}">Click to download</a>',
                        unsafe_allow_html=True
                    )
                if cols[4].button("Regenerate Repo"):
                    try:
                        shutil.rmtree(root_dir)
                    except:
                        pass
                    st.rerun()
        else:
            st.error("Requirement cannot be empty")


def show():
    st.markdown(f"<h1 style='text-align: center;'>Text to Code & Code to Cloud</h1>",
                unsafe_allow_html=True)
    requirements_step()
    if 'requirement_request' in state and state['requirement_request']:
        if 'active_text' in state and state['active_text'] and state['active_text'] == state['requirement_request']:
            generate_step()
        else:
            st.success("Click Magic to generate the repository")


# Execute the main function
if __name__ == "__main__":
    show()
