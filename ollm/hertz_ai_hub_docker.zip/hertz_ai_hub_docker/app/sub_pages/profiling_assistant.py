from collections import defaultdict
import shutil
import streamlit as st
import os
import json
import pandas as pd
import time
from .llm_utils import get_llm, llm_decorator, get_markdown_handler
import streamlit_antd_components as sac
import pandas as pd
import numpy as np
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
import streamlit.components.v1 as components
from ydata_profiling import ProfileReport
from .query import seasonal_query as rental_query
import sqlparse
from sqlalchemy import create_engine

if not 'pandas' in st.session_state:
    st.session_state.pandas = {}
state = st.session_state.pandas

prompt_statement = """You are an expert data analyst that interprets profiling reports of a pandas dataset.
You will provide a detailed narrative analysis of the dataset report. Prefer bullet points and concise sentences in markdown format for the response.
Enclose your analysis in triple backticks. Enunciate your observations in the response.

Please review the following report.
Sample:
=====
{sample}
=====

Summary:
=====
{summary}
=====

Metadata: 
=====
{table}
=====

Correlations: 
=====
{correlations}
=====

Missing Values: 
=====
{missing}
=====

Alerts:
=====
{alerts}
=====

Narrative Response: ```markdown
"""
    
@llm_decorator()
def generate_narrative(llm, sample, summary, table, correlations, missing, alerts, **kwargs):
    prompt = ChatPromptTemplate.from_template(prompt_statement)
    chain = prompt | llm
    return chain.invoke({'sample':sample, 'summary': summary, 'table': table, 'correlations':correlations, 'missing': missing, 'alerts':alerts}) #.strip().strip('```').strip()

@st.cache_data
def query_data(query: str):
    engine = create_engine(st.secrets["databricks_url"])
    # Fetch data
    data = pd.read_sql_query(query, engine, )
    return data

def custom_date_parser(x):
    return pd.to_datetime(x, format='%Y-%m-%d')  # Adjust the format as per your date format

def auto_convert_dates_to_datetime(df):
    for column in df.columns:
        if 'date' in column.lower() and df[column].dtype != 'datetime64[ns]':
            try:
                df[column] = pd.to_datetime(df[column])
            except Exception as e:
                print(f"Error converting column '{column}' to datetime: {e}")
    return df

def show():
    st.markdown(f"<h1 style='text-align: center;'>Profiling Assistant</h1>",
                unsafe_allow_html=True)
    btns = sac.segmented([sac.SegmentedItem(
        label=idx,) for idx in ['Upload', 'Query']], align='center')
    if btns == 'Upload':
        state['profile_report'] = None
        state['processed_file'] = state.get('processed_file', pd.read_parquet('uploaded_file.parquet') if os.path.exists('uploaded_file.parquet') else None)
        if 'processed_file' not in state or state['processed_file'] is None:
            with st.form(key="upload_form"):
                uploaded_file = st.file_uploader("Upload your DataFrame file", type=["csv", "xlsx", "parquet", "tsv"])
                submit = st.columns(9)[4].form_submit_button("Upload")
                if submit:
                    state['processed_file'] = None
                    with st.spinner("Reading..."):
                        if uploaded_file is not None:
                            file_extension = uploaded_file.name.split(".")[-1]
                            if file_extension == "csv":
                                df = pd.read_csv(uploaded_file, date_parser=custom_date_parser)
                            elif file_extension == "xlsx":
                                df = pd.read_excel(uploaded_file, date_parser=custom_date_parser)
                            elif file_extension == "parquet":
                                df = pd.read_parquet(uploaded_file, date_parser=custom_date_parser)
                            elif file_extension == "tsv":
                                df = pd.read_csv(uploaded_file, sep='\t', date_parser=custom_date_parser)
                            else:
                                st.error("Unsupported file format. Please upload a CSV, XLSX, Parquet, or TSV file.")
                            # Save uploaded file to session state
                            state['processed_file'] = df
                            # Save dataframe to Parquet
                            df.to_parquet('uploaded_file.parquet', index=False)
    if btns == 'Query':
        with st.form(key="query_form"):
            sql_query = st.text_area("Datalake Query", key="sql_query", value=sqlparse.format(rental_query, reindent=True, keyword_case='upper'),  height=330, help="Enter a search query to find tables and columns.")
            query_button = st.form_submit_button("Query")
            if query_button:
                state['processed_file'] = None
                if sql_query:
                    with st.spinner("Querying..."): # Perform search augmentation
                        data_df = query_data(sql_query)
                        state['processed_file'] = data_df
                        # Save dataframe to Parquet
                        data_df.to_parquet('uploaded_file.parquet', index=False)

    if state['processed_file'] is not None:
        state['processed_file'] = auto_convert_dates_to_datetime(state['processed_file'])
        df_frame = st.empty()
        df_table = df_frame.container()
        df_table.subheader("Current Dataframe", help="The current dataframe that has been uploaded.", divider=True)
        df_table.dataframe(state['processed_file'], use_container_width=True)
        btn_bar = st.columns(8)
        reset = btn_bar[3].button("Reset/Wipe", key=f"{str(abs(hash(id(state['processed_file']))))}wipe", help="Click to reset the uploaded file.")
        if reset:
            try:
                os.remove('uploaded_file.parquet')
            except:
                pass
            finally:
                df_frame.empty()
            state['processed_file'] = None
        if btn_bar[4].button("Generate Profiling Report", key="generate_report", help="Click to generate a profiling report."):
            state['profile_report'] = None
            if ('profile_report' not in state or state['profile_report'] is None) and state['processed_file'] is not None:
                with st.spinner("Loading..."):
                    df = state['processed_file']
                    profile = ProfileReport(df, explorative=True, )
                    state['profile_report'] = profile
            if 'profile_report' in state and state['profile_report'] is not None:
                def get_description_set(profile, fieldname, default=""):
                    try:
                        description_set = profile.description_set
                        return description_set['fields'].get(fieldname, default)
                    except:
                        return default
                narrative_animation = st.empty()
                narrative_text = generate_narrative(
                    sample=state['processed_file'].sample(3).to_markdown() if state['processed_file'] is not None else "No data available.",
                    summary=state['processed_file'].describe(include='all').to_markdown() if state['processed_file'] is not None else "No summary available.",
                    table=get_description_set(state['profile_report'], 'table', ""),
                    correlations=get_description_set(state['profile_report'], 'correlations', ""),
                    missing=get_description_set(state['profile_report'], 'missing', ""),
                    alerts=get_description_set(state['profile_report'], 'alerts', ""),
                    md_output=get_markdown_handler(narrative_animation, "", code=True), stop=["```", "]]]"], model_name="neural-chat", timeout=120)
                narrative_animation.markdown(narrative_text)
                st.markdown(f"<h1 style='text-align: center;'>Profiling Report</h1>",
                            unsafe_allow_html=True)
                report = state['profile_report'].to_html()
                components.html(report, height=3000)
        

# Execute the main function
if __name__ == "__main__":
    show()
