from datetime import datetime
from .llm_utils import llm_decorator, get_markdown_handler
from utils import draw_header
import streamlit as st
from langchain.prompts import PromptTemplate
from langchain_core.prompts import PromptTemplate
import streamlit_antd_components as sac
import json
from langchain_community.vectorstores import FAISS
from langchain_community.document_loaders import DataFrameLoader
from langchain.embeddings import HuggingFaceEmbeddings
from langchain.retrievers import BM25Retriever, EnsembleRetriever
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnablePassthrough, RunnableParallel, RunnableLambda
import re, json, os, shutil
import pandas as pd
import sqlparse
from sqlalchemy import create_engine

if 'sql_demo' not in st.session_state:
    st.session_state.sql_demo = {}
state = st.session_state.sql_demo

def get_catalog_df():
    df = pd.read_parquet('process_file.parquet') if os.path.exists('process_file.parquet') else pd.DataFrame([], columns=['table_catalog', 'table_schema', 'table_name', 'columns', 'column_types', 'hints', 'table_description', 'column_descriptions', 'column_description'], dtype=str)
    df = df[df['table_description'].notnull()]
    return df

def index_vectorstore(sidebar):
    try:
        with sidebar:
            with st.spinner("Indexing vector database..."):
                pdf = get_catalog_df().copy()
                pdf['_text'] = pdf[['table_name', 'table_description', 'column_descriptions']].fillna('').astype(str).apply(lambda row: '\n'.join([f'{kv[0]}:`{kv[1]}`' for kv in dict(row).items()]), axis=1)
                docs = DataFrameLoader(pdf, page_content_column="_text").load()
                embeddings = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")
                bm25_retriever = BM25Retriever.from_documents(docs, k=5)
                vectordb = FAISS.from_documents(docs, embeddings)
                # Define retriever
                retriever = vectordb
                vector_retriever = retriever.as_retriever(search_kwargs={"k": 5})
                ensemble_retriever = EnsembleRetriever(
                    retrievers=[bm25_retriever, vector_retriever], weights=[0.3, 0.7]
                )
                state['retriever'] = ensemble_retriever
                state['vectorstore'] = vectordb
                sidebar.success("Indexed successfully.")
    except Exception as e:
        sidebar.error(f"Indexing failed: {e}")


@llm_decorator()
def correct_query(llm, query, **kwargs):
    prompt = PromptTemplate.from_template("""Given a natural language search query that may have typos or can lack clarity, return THE corrected query in no more than 5 words or less. Respond ONLY with the corrected query. Do NOT spew any extra response than the corrected query. 
Enclose your corrected query in triple backticks.
For an example query: 'num reservtion 2023', your corrected query can be: ```total reservations in 2023```

Now, correct the below query:
Query: `{query}`
Corrected query: ```""")
    chain = prompt | llm
    return chain.invoke({'query':query}).strip().strip('```').strip()

def search_vector(query):
    if 'retriever' not in state:
        raise Exception("Vectorstore not indexed.")
    chain = state['retriever'] #| RunnableLambda(lambda results: pd.DataFrame([result.metadata for result in results]).head(5))
    return chain.invoke(query) #.strip().strip('```').strip()

@llm_decorator()
def sql_chain(llm, query, context, **kwargs):
    prompt = """You are an EXPERT SQL writer that can write accurate SQL92/Sqlite query to answer a user's question.
You must respond with a SQL query that accurately answers the user question.
You will be presented with a list of table name (a combination of catalog, schema, tablename), table description, and columns from the warehouse in your context. MULTIPLE tables are presented in descending order of relevance in the context (in JSON format).
You do NOT have to use ALL the tables in the context; use fewest tables, preferably the first table, at the top to write your SQL query.
Compose the query that is easy, correct, and MOST succint: Do NOT complicate with extraneous clauses, assumptions of user question.
PLEASE choose parsimony over verbosity. You MUST always choose fewest columns and tables to answer the user query.
Your response will be a single SQL statement that answers user's query.
PLEASE VERIFY column names and table names are correct. Do NOT change columns like `response_id` to `responseId`.
Enclose your SQL query in triple backticks. 

For an example question and context below in JSON format: 
    Question: `What are the ids and full names of the customers whose first name is John?` 
    Context: {{'table':'sfdc.mktg.customer', 'table_description':'customer information', 'columns':['customer_id', 'customer_name']}}`
Your response will be: 
    ```sql SELECT customer_id, customer_name FROM sfdc.mktg.customer WHERE customer_name LIKE 'John%'```

Now, respond to the below question. Use the context presented in JSON format.
Question: `{query}`
Context: `{context}`
Response: ```sql """
    prompt_template = PromptTemplate.from_template(prompt)
    chain = prompt_template | llm
    return sqlparse.format(chain.invoke({'query':query, 'context':context}).strip().strip('```').strip(), reindent=True, keyword_case='upper')

@st.cache_data
def query_data(query: str):
    engine = create_engine(st.secrets["databricks_url"])
    # Fetch data
    data = pd.read_sql_query(query, engine)
    return data

def show():
    sidebar = st.sidebar
    with sidebar:
        with sidebar.form("Search Catalog") as form:
            st.header("Annotated Catalog", divider=True)
            df_div = st.empty()
            df_div.dataframe(get_catalog_df(), use_container_width=True)
            index_button = st.columns(3)[1].form_submit_button("Index", help="Index the catalog for search.")
            if index_button:
                index_vectorstore(sidebar)
    if 'vectorstore' in state:
        button_texts = ['average wait time on phone', 'number of reservations in 2024', 'number of no shows by customer named John', 'number of nps responses']
        with st.container(): #(key="search_form"):
            st.markdown("---\n### Search Tables and Columns")
            search_query = st.text_input("Search query", st.session_state.get('search_query', button_texts[0]), help="Enter a search query to find tables and columns.")
            btns = st.empty()
            search_button = st.button("Search")
            with btns:
                selected_query = sac.buttons(button_texts, size='xs', key='search_btns', label="Quick Queries")
                if selected_query and selected_query != search_query:
                    search_query = selected_query
                    # Update the value of the text input field
                    st.session_state['search_query'] = search_query
            st.markdown("---")
            if search_button:
                state['active_result'] = None
                if 'query_history' not in state:
                    state['query_history'] = []
                if search_query and search_query not in [query['query'] for query in state['query_history']]:
                    answer_div = st.empty()
                    with st.spinner("Augmenting..."): # Perform search augmentation
                        corrected_query = correct_query(search_query)
                        answer_div.write(corrected_query)

                    with st.spinner("Generating SQL..."): # Perform search operation
                        results_vector = search_vector(f"{search_query} {corrected_query}")
                        results_df = pd.DataFrame.from_dict([result.metadata for result in results_vector[:5]]).head(5)
                        answer_div.write(results_df)
                        
                        state['active_result'] = results_df
                        # Save query history
                        toc_df = results_df.copy()
                        sql_context = toc_df.copy()
                        sql_code = st.empty()
                        sql_context['table'] = sql_context['table_catalog'] + '.' + sql_context['table_schema'] + '.' + sql_context['table_name']
                        context = sql_context[['table', 'table_description', 'columns']].head(1).to_dict(orient='records')
                        sql_code_output = sql_chain(corrected_query, context, model_name="neural-chat",  md_output=get_markdown_handler(sql_code, "", code=True), stop=["```", "]]]"])
                        sql_code.empty()
                        error = ''
                        try:
                            df_result = query_data(sql_code_output)
                            answer_div.table(df_result)
                        except Exception as e:
                            df_result = None
                            error = str(e)
                            st.error(f"SQL query failed: {e}")
                        state['query_history'].append({
                            'query': search_query,
                            'corrected_query': corrected_query,
                            'timestamp': datetime.now(),
                            'results_vector': results_df,
                            'sql_query': sql_code_output,
                            'sql_output': df_result,
                            'sql_error': error
                        })
                        
                    answer_div.empty()

    if 'query_history' in state and state['query_history'][:5]:
        if st.columns(7)[3].button("Clear history"):
            state['query_history'] = []
        
    if 'query_history' in state and state['query_history'][:5]:
        st.markdown("---\n### Prior Results")
        with st.container():
            for i, query in enumerate(reversed(state['query_history'][-5:])):
                if query['results_vector'] is None:
                    continue
                label, result, delete = st.columns([1, 6, 1])
                with label:
                    st.write(f"# {i+1}")
                with result.expander(f"# Query: {query['query']}", expanded=True) as expander:
                    vector_results = st.container()
                    if query['results_vector'] is not None:
                        vector_results.write("Vector Results:")
                        vector_results.dataframe(query['results_vector'])
                    else:
                        vector_results.warning("No results found.")
                    sql_code_output = st.container()
                    if query['sql_query']:
                        sql_code_output.write("SQL Query:")
                        sql_code_output.code(query['sql_query'])
                    else:
                        sql_code_output.warning("SQL Not Found.")
                    sql_error_output = st.container()
                    if query['sql_error']:
                        sql_error_output.error("SQL Error:")
                        sql_error_output.code(query['sql_error'])
                    df_output = st.container()
                    if query['sql_output'] is not None:
                        df_output.write("SQL Output:")
                        df_output.dataframe(query['sql_output'])
                        import plotly.express as px
                        fig = px.bar(query['sql_output'])
                        st.plotly_chart(fig)
                    else:
                        df_output.warning("Error executing SQL.")
                with delete:
                    if st.button("Delete", key=f"delete_{i}"):
                        # Delete the item from query_history list
                        index_to_delete = len(state['query_history']) - i - 1
                        del state['query_history'][index_to_delete]