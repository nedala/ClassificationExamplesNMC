from collections import defaultdict
import shutil
import streamlit as st
import os
import json
import pandas as pd
import time
from .llm_utils import get_llm, llm_decorator, get_markdown_handler
import streamlit_antd_components as sac
import pandas as pd
import numpy as np
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate

if not 'spelling' in st.session_state:
    st.session_state.spelling = {}
state = st.session_state.spelling

prompt_statement = """You are an English teacher who articulates very clearly.
When supplied a text that can potentially have errors or lacks clarity, you will rewrite the same text in a more concise, correct, and articulate manner.
Your response will be brief, on-point, precise, and clear. You are prohibited from changing the meaning of the text.
You will analyze text for spelling errors, grammatical errors, and clarity -- paragraph by paragraph, sentence by sentence, word by word.
You will NOT be disrespectful or use offensive words/language.
You will be tolerant to professional jargon and technical terms.
Do NOT create hypothetical scenarios or add any additional information.
Maintain structure, tone, and intent of the text. Newlines should be maintained.
For an example text like:
`
How is you?

Reach emergentcy number 911.
`
You should rewrite it as:
`
How are you?

Reach emergency number at 911.
`
End your rewritten text with triple backticks.
Text:
`
{text}
`
Rewritten message: ```
"""


@llm_decorator()
def correct(llm, text, **kwargs):
    prompt = ChatPromptTemplate.from_template(prompt_statement)
    chain = prompt | llm | StrOutputParser()
    return chain.invoke({'text': text}).strip().strip('```').strip()

typos = """Yesterday, I am going to the supply room. A customer will go up to me and said they needed help.

President Biden delivered her speech from the the Cpatiol."""

def show():
    st.markdown(f"<h1 style='text-align: center;'>Grammar Assistant</h1>",
                unsafe_allow_html=True)
    form1 = st.form(key="english_convert")
    with form1:
        text = st.text_area("Enter text to translate", typos, height=200, max_chars=4096)
        submit = st.columns(9)[4].form_submit_button("Correct")
        if submit:
            with st.spinner("Analyzing..."):
                message = st.empty()
                translation = correct(text, md_output=get_markdown_handler(message, "", code=False))
                message.code(translation, language='text')

# Execute the main function
if __name__ == "__main__":
    show()
