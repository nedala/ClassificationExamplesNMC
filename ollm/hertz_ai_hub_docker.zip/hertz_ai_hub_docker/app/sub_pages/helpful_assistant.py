import shutil
import streamlit as st
import os
import pandas as pd
from .llm_utils import llm_decorator, get_markdown_handler
import streamlit_antd_components as sac
import pandas as pd
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_community.embeddings.sentence_transformer import (
    SentenceTransformerEmbeddings,
)
from langchain_community.vectorstores import FAISS
from langchain_community.vectorstores.faiss import DistanceStrategy

if not 'help' in st.session_state:
    st.session_state.help = {}
state = st.session_state.help

def get_embedding_model():
    if not hasattr(get_embedding_model, "model"):
        get_embedding_model.model = SentenceTransformerEmbeddings(model_name='sentence-transformers/all-mpnet-base-v2')
    return get_embedding_model.model


persist_db = 'knowledge_base.db'
if not hasattr(state, "chroma_db"):
    state['chroma_db'] = None if not os.path.exists(persist_db) else FAISS.load_local(persist_db, get_embedding_model(), allow_dangerous_deserialization=True, distance_strategy=DistanceStrategy.MAX_INNER_PRODUCT)


def draw_header(icon, text): return sac.divider(
    label=text, icon=icon, align='center', color='gray')


prompt_statement = """You are a helpful assistant. You will answer questions respectfully, factually, and succintly. 
When the user asks a question, you may be presented a JSON context containing the answer to the question. Analyze the context and answer the question.
If the context is not sufficient to answer the question, you MUST provide response from your Internet knowledge.
PLEASE NOTE:
 - The context can combine multiple unrelated documents. Do NOT mix up information from different documents of the context.
 - Assume that the context presents documents in descending order of relevance. Also pay attention to text of the source.
 - If the context is not sufficient to answer the question, you MUST provide response from your Internet knowledge.

Context: '''{context}'''
Question: `{question}`
Answer: ```
"""

prompt_internet_statement = """You are a helpful assistant. You will answer questions respectfully, factually, and succintly. 
Question: `{question}`
Answer: ```
"""


@llm_decorator()
def answer_question(llm, question, context, **kwargs):
    prompt = ChatPromptTemplate.from_template(prompt_statement if context else prompt_internet_statement)
    chain = prompt | llm | StrOutputParser()
    return chain.invoke({'question': question, 'context':context if context else '[]'}).strip().strip('```').strip()


def load_pandas_using_langchain(pdf):
    from langchain_community.document_loaders import DataFrameLoader
    pdf['text'] = pdf.fillna('').apply(
        lambda row: ' '.join(row.values.astype(str)), axis=1)
    loader = DataFrameLoader(pdf, page_content_column="text")
    documents = loader.load()
    save_to_index(documents)
    return documents


def load_pdf_using_langchain(pdf_filename):
    from langchain_community.document_loaders import UnstructuredPDFLoader
    loader = UnstructuredPDFLoader(pdf_filename, mode="elements")
    documents = loader.load()
    save_to_index(documents)
    return documents


def load_docx_using_langchain(pdf_filename):
    from langchain_community.document_loaders import UnstructuredWordDocumentLoader
    loader = UnstructuredWordDocumentLoader(pdf_filename, mode="elements")
    documents = loader.load()
    save_to_index(documents)
    return documents


def save_to_index(documents, persist_db='knowledge_base.db'):
    if not os.path.exists(persist_db):
        index = FAISS.from_documents(documents, get_embedding_model(), distance_strategy=DistanceStrategy.MAX_INNER_PRODUCT)
        state['chroma_db'] = index
    else:
        existing_index = FAISS.load_local(persist_db, get_embedding_model(), allow_dangerous_deserialization=True)
        new_index = FAISS.from_documents(documents, get_embedding_model(), distance_strategy=DistanceStrategy.MAX_INNER_PRODUCT)
        existing_index.merge_from(new_index)
        state['chroma_db'] = existing_index
    state['chroma_db'].save_local(persist_db)


def search_index(query, n=5):
    return [result for result in state['chroma_db'].similarity_search_with_score(query, k=n) if result[1] >= 0.1]

@llm_decorator()
def answer_qa(llm, query, **kwargs):
    from langchain.chains import VectorDBQA
    if not hasattr(state, "vectordb"):
        state['vectordb'] = VectorDBQA.from_chain_type(llm=llm, chain_type="stuff", vectorstore=state['chroma_db'])
    return state['vectordb'].run(query)

def merge_content(dict_contents, score):
    if not dict_contents:
        return {}
    else:
        dict_contents.update({'score': score})
        return dict_contents
    
def search_step():
    draw_header("search", "Search Knowledge Base")
    search_view = st.container()
    with search_view.form("search-form", clear_on_submit=True):
        query = st.text_input("Answer questions", key="searchbox")
        internet_context = sac.switch(label='Use Internet Knowledge?', align='center', size='md', key='internet_context')
        submitted = st.form_submit_button("Search")
        if submitted:
            with st.spinner(f"Searching for `{query}`"):
                with search_view:
                    pd_view, answer_view = search_view.columns([1, 2])
                    try:
                        context = pd.DataFrame()
                        try:
                            results = search_index(query, 50)
                            # context = pd.DataFrame.from_records([merge_content(result.metadata, result.page_content, score) for (result, score) in results]).groupby('source').agg({'page_content': lambda x: '\n'.join(x), 'score': lambda x: sum(x)/len(x)}).sort_values(by='score', ascending=False) if results else pd.DataFrame()
                            context = pd.DataFrame.from_records([merge_content(result.metadata, score) for (result, score) in results]) if results else pd.DataFrame()
                        except Exception as e:
                            pd_view.error(f"Error searching for `{query}` {e}")
                            pass
                        pd_view.success(f"Found {len(results)} documents")
                        pd_view.write(context)
                        new_output = answer_view.empty()
                        response = answer_question(query, context.head(3).to_json(orient='records') if not internet_context else None, md_output=get_markdown_handler(new_output, "", True))
                        answer_view.write(response)
                    except Exception as e:
                        st.error(f"Error searching for `{query}` {e}")
                        new_output = answer_view.empty()
                        response = answer_question(query, None, md_output=get_markdown_handler(new_output, "", code=True))
                        answer_view.write(response)


def upload_step():
    draw_header("upload", "Upload Documents")
    upload_view = st.container()
    # Streamlit UI
    # File upload section
    browse_view = upload_view.container()

    def read_file(file):
        if file.name.split('.')[-1] in ['xls', 'xlsx']:
            try:
                df = pd.read_excel(file)
                documents = load_pandas_using_langchain(df)
                st.success(
                    f"Loaded {len(documents)} documents from the Excel file")
            except Exception as e:
                st.error(f"Error reading Excel file: {e}")
                return None
        elif file.name.split('.')[-1] in ['csv', 'tsv']:
            try:
                df = pd.read_csv(file, sep='\t' if file.name.split(
                    '.')[-1] in ['tsv'] else ',', encoding='utf-8')
                documents = load_pandas_using_langchain(df)
                st.success(
                    f"Loaded {len(documents)} documents from the CSV file")
            except Exception as e:
                st.error(f"Error reading CSV file: {e}")
                return None
        elif file.name.split('.')[-1] in ['parquet']:
            try:
                df = pd.read_parquet(file)
                documents = load_pandas_using_langchain(df)
                st.success(
                    f"Loaded {len(documents)} documents from the Parquet file")
            except Exception as e:
                st.error(f"Error reading Parquet file: {e}")
                return None
        elif file.name.split('.')[-1] in ['pdf']:
            if file is not None:
                try:
                    # Save the file to the uploads directory
                    file_path = os.path.join("uploads", file.name)
                    os.makedirs("uploads", exist_ok=True)
                    with open(file_path, "wb") as f:
                        f.write(file.getbuffer())
                    documents = load_pdf_using_langchain(file_path)
                    st.success(
                        f"Loaded {len(documents)} documents from the PDF file")
                except Exception as e:
                    st.error(f"Error reading PDF file: {e}")
        elif file.name.split('.')[-1] in ['doc', 'docx']:
            if file is not None:
                try:
                    # Save the file to the uploads directory
                    file_path = os.path.join("uploads", file.name)
                    os.makedirs("uploads", exist_ok=True)
                    with open(file_path, "wb") as f:
                        f.write(file.getbuffer())
                    documents = load_docx_using_langchain(file_path)
                    st.success(
                        f"Loaded {len(documents)} documents from the Word file")
                except Exception as e:
                    st.error(f"Error reading Word file: {e}")
        else:
            st.error(
                f"Unsupported file format -- {file.type}. Please upload a CSV, XLSX, Parquet, Word, or Pdf file.")
            return None

        return df
    with browse_view.form("kb-form", clear_on_submit=True):
        file = st.file_uploader("(Optional) upload a CSV/XLSX/Parquet/PDF/DOCX file", type=[
            'csv', 'xlsx', 'parquet', 'pdf', 'docx'])
        submitted = st.form_submit_button("Upload")
        if submitted:
            with st.spinner(f"Analyzing and indexing to `{file.name}`"):
                with browse_view:
                    try:
                        read_file(file)
                        st.success(f"Indexed knowledge base from {file.name}")
                    except:
                        st.error(f"Error reading file: {file.name}")
    if browse_view.columns(7)[3].button("Clear Index"):
        if os.path.exists(persist_db):
            shutil.rmtree(persist_db)
            state['chroma_db'] = None
            st.success("Cleared the knowledge base index")
        else:
            st.error("No knowledge base index to clear")


def show():
    st.markdown(f"<h1 style='text-align: center;'>Helpful Assistant</h1>",
                unsafe_allow_html=True)
    btns = sac.segmented([sac.SegmentedItem(
        label=idx,) for idx in ['Index', 'Concierge']], align='center')
    if btns == 'Concierge':
        search_step()
    elif btns == 'Index':
        upload_step()
    pass


# Execute the main function
if __name__ == "__main__":
    show()
