from datetime import datetime
from .llm_utils import llm_decorator, get_markdown_handler
from utils import draw_header
import streamlit as st
import streamlit_antd_components as sac
from langchain.prompts import PromptTemplate
from langchain_core.prompts import PromptTemplate
import streamlit_antd_components as sac
from langchain.prompts import PromptTemplate
from langchain_core.prompts import PromptTemplate
import json
import re, json, os, shutil
from sqlalchemy import create_engine
from fuzzywuzzy import process, fuzz
import pandas as pd
from functools import reduce
import nltk
nltk.download('words')
from nltk.corpus import words

if 'catalog_demo' not in st.session_state:
    st.session_state.catalog_demo = {}
state = st.session_state.catalog_demo

table_prompt = """You are an EXPERT data steward with enterprise IT analytics group of Hertz, a car rental company.

Your responsibility is to catalog the data warehouse so business community can understand the warehouse assets better using natural language.

You are given the name of a table, and a list of constituent columns in the table from a data warehouse -- one at a time.

The columns are presented a JSON list of strings. Table name is just a simple string.

Some of the column names can be snake_cased or camelCased; some words can also collapse into one another without any case or space distinction.

Given the table and column names can also be using shortcodes (such as NUM for number, LOC for location, ID for identifier, LAT for latitude, LON for longitude etc), you may be provided some additional hints on what the short forms can potentially mean in the enterprise context. Use these hints ONLY if applicable. You can ignore the hints if they are not applicable. You may also infer most of these shortcodes using soundex/phoneme codes within reasonable limits of a rental car company context.

You are responsible to write a short description of the given table that describes the business intent of this table in simple natural language. Technical jargonry is disallowed.

Your response CANNOT include any pronouns (I, we, you, they, it, etc.) or any references to the data warehouse, the company, or any other proper nouns.

Do NOT include unnecessary catalog, schema, table, or column information in your response. Assume that the business community already knows that information.

Your response should be surrounded by backticks ```.

For an example Input: {{'table': 'sat_customer_rentals', 'columns': ['customer_id', 'customer_age', 'customer_dob', 'customer_name', 'customer_ra_nbr', 'customer_phone', 'customer_email', 'pkup_dt', 'rtn_dt'], 'hints': {{'hdp':'Hertz Data Platform', 'sat':'Satellite table', 'bkup':'Backup', 'RA':'Rental Agreement', 'nbr':'number', 'dob':'date of birth'}} }}

Your response may look like: ```This table has customer (identified by their unique ID (identifier), DOB (date of birth), name, contact information) mapped to their rental agreements (identified by RA (rental agreement) number, pickup datetime and return datetime).```

Analyze deeply. BE brief in your response (your response cannot exceed 8 sentences and shorter than ~100 words). 

You will be penalized for rambling unnecessary spewage.

Use the following JSON as your input:
    {{table: '{table}', columns: {columns}, hints: {hints} }}

Description: ```
"""

column_prompt = """You are an EXPERT data steward with enterprise IT analytics group of Hertz, a car rental company.

You are given a table, a table description, and a list of constituent columns in the table from a data warehouse.

The table and the table description are strings. The columns of the table are presented as a JSON list of strings.

Given some columns and table names can use short codes (acronyms and abbreviations), you may be provided some additional hints on what the short forms may potentially mean in the context. Use these hints ONLY if applicable. You can ignore the hints if they are not applicable. You may also infer most of these shortcodes using soundex/phoneme codes within reasonable limits of rental car company context.

You are responsible for generating the raw column name, "canonical" representation of the column, and a column description in English for each of the table columns.

Your response must be a JSON list of three-item tuples -- [{{tuples -- each tuple corresponding per column}}] where each tuple is ({{column name as-is}}, {{canonical representation of the column}}, {{short english description of the column}}).

Surround your response in backticks ```.

For an example input: {{'table': 'customer', 'columns': ['customer_id', 'customer_age', 'customer_dob', 'customer_name'], 'hints': {{'nbr':'number', 'dob':'date of birth'}}, 'table_description': 'The table is a list of customers. Each customer has a unique identifier, date of birth, age, and name.' }}

Your response can be like this: ```
[
    ("customer_id", "Customer Identifier", "Unique identifier for the customer."),
    ("customer_age", "Customer Age", "Age of the Customer."),
    ("customer_dob", "Customer Date of Birth", "Birthdate of the customer."),
    ("customer_name", "Customer Name", "Name of the Customer.")
]
```

Use the following as your input:
{{'table': '{table}', 'columns': {columns}, 'hints': {hints}, 'table_description': '{table_description}' }}

Response: ```
"""

rewrite_prompt = """You are an EXPERT data steward with enterprise IT analytics group of Hertz, a car rental company.

Your responsibility is to catalog the data warehouse so business community can understand the warehouse assets better using natural language.

For a table that has the columns as described in the input (in JSON format), you are responsible for generating a short natural language description of the table in 8 sentences (200 words) or less.

You are responsible to write a short description of the given table that describes the business intent of this table in simple natural language. Technical jargonry is disallowed.

Your response CANNOT include any pronouns (I, we, you, they, it, etc.) or any references to the data warehouse, the company, or any other proper nouns.

Do NOT include unnecessary catalog, schema, table, or column information in your response. Assume that the business community already knows that information.

Use the following as your input:
{{'table': '{table}', 'columns': {columns} }}

Description: ```
"""

def decompose_column_tokens(column_name):
    if not hasattr(decompose_column_tokens, 'english_words'):
        decompose_column_tokens.english_words = set([word.lower() for word in words.words()])
    # Use regular expression to split the column name by underscores, camelCase, and non-alphanumeric characters
    components = re.findall(r'[A-Z]+(?=[A-Z][a-z]+)|[A-Z]?[a-z]+|[A-Z]+|\d+|\W+', column_name)
    return sorted([y for y in components if y.isalpha()])

def collect_strings(text):
    pattern = r'"([^"]*)"|\'([^\']*)\''
    strings = re.findall(pattern, text)
    return [s[0] or s[1] for s in strings]


@llm_decorator()
def generate_table_description(llm, tbl_prompt, table_name, columns, hints={}, **kwargs):
    file_llm_chain = PromptTemplate.from_template(tbl_prompt) | llm
    result = file_llm_chain.invoke({'table':table_name, 'columns':json.dumps(columns), 'hints': json.dumps(hints if hints else {})})
    return result

@llm_decorator()
def generate_column_descriptions(llm, column_prompt, table_name, columns, hints, table_description, **kwargs):
    file_llm_chain = PromptTemplate.from_template(column_prompt) | llm
    result = file_llm_chain.invoke({'table':table_name, 'columns':json.dumps(columns), 'hints': json.dumps(hints if hints else {}), 'table_description': table_description})
    return result

def read_ignore_strings():
    if 'ignore_strings' in state:
        del state['ignore_strings']
    if 'ignore_strings' not in state or not state['ignore_strings']:
        if os.path.exists('regex_replace_rules.csv'):
            patterns = pd.read_csv('regex_replace_rules.csv', dtype=str)['EXPRESSION'].dropna().str.upper().drop_duplicates().tolist()
            regex_pattern = re.compile("|".join(map(re.escape, patterns)), re.IGNORECASE)
            # Apply regex substitution using functools.reduce
            re_column = lambda input_string: reduce(lambda s, pattern: regex_pattern.sub("", s), patterns, input_string)
            state['ignore_strings'] = patterns
            state['re_column'] = re_column
        else:
            state['ignore_strings'] = []
            state['re_column'] = lambda x: x
    else:
        state['ignore_strings'] = []
        state['re_column'] = lambda x: x

def read_abbreviations():
    if 'abbreviations' in state:
        state['abbreviations'] = None
    if 'abbreviations' not in state or not state['abbreviations']:
        if os.path.exists('abbrevs.parquet'):
            abbreviations_df = pd.read_parquet('abbrevs.parquet')
            state['abbreviations'] = abbreviations_df
        else:
            state['abbreviations'] = pd.DataFrame([], columns=['Abbreviation', 'Full_Form'], dtype=str)
    else:
        state['abbreviations'] = pd.DataFrame([], columns=['Abbreviation', 'Full_Form'], dtype=str)

def read_catalog_queue():
    if 'catalog' in state:
        state['catalog'] = None
    if 'catalog' not in state or not state['catalog']:
        if os.path.exists('catalog.parquet'):
            state['catalog'] = pd.read_parquet('catalog.parquet')
        else:
            state['catalog'] = pd.DataFrame([], columns=['table_catalog', 'table_schema', 'table_name', 'columns'], dtype=str)
    else:
        state['catalog'] = pd.DataFrame([], columns=['table_catalog', 'table_schema', 'table_name', 'columns'], dtype=str)

def remove_consecutive_duplicates(lst):
    result = []
    prev_item = None
    for item in lst:
        if item != prev_item:
            result.append(item)
        prev_item = item
    return result
    
# Function to match components with abbreviations
def match_abbreviations(components):
    abbreviations_df = state['abbreviations']
    full_forms = []
    for component in components:
        possible_abbreviations = abbreviations_df[(abbreviations_df['Abbreviation'].str.len() == len(component)) & (len(component) >= 2)]
        matches = process.extractOne(component, possible_abbreviations['Abbreviation'], scorer=fuzz.partial_ratio)
        if matches and matches[1] >= 98 and len(matches[0]) >= len(component):
            full_forms.append((component, abbreviations_df.loc[abbreviations_df['Abbreviation'] == matches[0], 'Full_Form'].values[0]))
    return list(set(full_forms))

def rm_r(path):
    if not os.path.exists(path):
        return
    if os.path.isfile(path) or os.path.islink(path):
        os.unlink(path)
    else:
        shutil.rmtree(path)


def delete_abbreviations():
    if os.path.exists('abbrevs.parquet'):
        rm_r('abbrevs.parquet')
        st.success("Abbreviations file deleted successfully.")
    else:
        st.warning("Abbreviations file does not exist.")
    read_abbreviations()

def delete_ignores():
    if os.path.exists('regex_replace_rules.csv'):
        rm_r('regex_replace_rules.csv')
        st.success("Ignore strings file deleted successfully.")
    else:
        st.warning("Ignore strings file does not exist.")
    read_ignore_strings()

def delete_df():
    if os.path.exists('catalog.parquet'):
        rm_r('catalog.parquet')
        st.success("Wiped catalog queue.")
    else:
        st.warning("Catalog queue does not exist.")
    read_catalog_queue()

@st.cache_data
def query_data(query: str):
    engine = create_engine(st.secrets["databricks_url"])
    # Fetch data
    data = pd.read_sql_query(query, engine)
    return data

@st.cache_data
def get_catalog_listing(catalog):
    query = f'''
    SELECT 
        table_catalog,
        table_schema,
        table_name,
        CONCAT('[', CONCAT_WS(', ', COLLECT_LIST(CONCAT('"', column_name, '"'))), ']') AS columns,
        CONCAT('[', CONCAT_WS(', ', COLLECT_LIST(CONCAT('"', column_name, ':', LOWER(data_type), '"'))), ']') AS column_types,
        NULL AS hints,
        NULL AS table_description,
        NULL AS column_descriptions,
        NULL AS column_description
    FROM 
        (
            SELECT 
                "{catalog}" as table_catalog,
                table_schema,
                table_name,
                column_name,
                data_type
            FROM 
                `{catalog}`.information_schema.columns 
            WHERE 
                table_schema NOT IN ('information_schema', 'pg_catalog')
        )
    GROUP BY 
        table_catalog, table_schema, table_name'''
    return query_data(query)

def parse_column_list(text):
    # Define the regular expression pattern to match each tuple
    pattern = r'"([^"]+)",\s*"([^"]+)",\s*"([^"]+)"'

    # Find all matches of the pattern in the text
    matches = re.findall(pattern, text)

    # Return a list of tuples containing the extracted components
    return matches

def show_cataloging():
    sidebar = st.sidebar
    with sidebar:
        st.header('Progress Indicator')
        progress_bar = st.progress(1.0)
        state['progress_bar'] = progress_bar

        st.write("---")
        st.header('Configuration', divider=True)
        with st.expander("Custom Shortcodes"):
            abbreviations_file = st.file_uploader("Upload your abbreviations CSV file", type=["csv"], help="Inject the abbreviations to be used for the LLM model.")
            if abbreviations_file is not None:
                abbreviations_df = pd.read_csv(abbreviations_file)
                abbreviations_df['Abbreviation'] = abbreviations_df['Abbreviation'].str.upper()
                abbreviations_df['Full_Form'] = abbreviations_df['Full_Form'].str.upper()
                abbreviations_df.dropna().drop_duplicates().replace('', pd.NA, inplace=True)
                abbreviations_df.dropna().drop_duplicates().to_parquet('abbrevs.parquet', index=False)

            delete_abbreviations_button = st.button("Reset", on_click=delete_abbreviations, key='delete_abbreviations')
            if delete_abbreviations_button:
                state['abbreviations'] = None
                rm_r('abbrevs.parquet')
            abbrev_site = st.empty()
            read_abbreviations()
            abbrevs_edited_df = abbrev_site.data_editor(state['abbreviations'], use_container_width=True, num_rows='dynamic', key='abbrevs')
            abbrevs_edited_df.dropna().drop_duplicates().replace('', pd.NA, inplace=True)
            abbrevs_edited_df.dropna().drop_duplicates().to_parquet('abbrevs.parquet', index=False)
            state['abbreviations'] = abbrevs_edited_df

        with st.expander("Ignore Strings"):
            regex_file = st.file_uploader("Upload the ignore strings file", type=["csv"], help="Upload the ignore strings file to ignore certain patterns in the column names.")
            if regex_file is not None:
                regex_df = pd.read_csv(regex_file)
                regex_df.to_csv('regex_replace_rules.csv', index=False)
            delete_ignores_button = st.button("Reset", on_click=delete_ignores, key='delete_ignores')
            if delete_ignores_button:
                state['ignore_strings'] = []
                delete_ignores()
            read_ignore_strings()
            ignore_strings = state['ignore_strings']
            ignore_strings = st.multiselect("Ignore Strings", options=ignore_strings, default=ignore_strings)
            state['ignore_strings'] = ignore_strings

        st.write("---")
        st.header('Prompts', divider=True)
        state['table_prompt'] = table_prompt
        with st.expander("Table Prompt"):
            with st.form("Table Prompt"):
                state['table_prompt'] = st.text_area("Table Description Prompt", table_prompt)
                st.form_submit_button("Save Table Prompt")

        with st.expander("Column Prompt"):
            with st.form("Column Prompt"):
                state['column_prompt'] = st.text_area("Column Description Prompt", column_prompt)
                st.form_submit_button("Save Column Prompt")

        st.write("---")
        st.header('Catalog Queue', divider=True)
        load_tab, uploaded_tab, scanned_tab = st.tabs(['Load', 'Upload', 'Scan'])
        with load_tab:
            if os.path.exists('process_file.parquet'):
                load_catalog_button = st.button("Load Processed Catalog", key='load_old_catalog') 
                if load_catalog_button:
                    pd.read_parquet('process_file.parquet').to_parquet('catalog.parquet', index=False)
                    read_catalog_queue()
                    load_tab.success("Prior catalog loaded successfully.")
            else:
                load_tab.error("No pre-processed catalog found.")
        with uploaded_tab:
            catalog_file = st.file_uploader("Upload your catalog", type=["csv"], key='catalog_file', help="Upload your catalog to be processed.")
            if catalog_file is not None:
                state['catalog'] = pd.read_csv(catalog_file, usecols=['table_catalog', 'table_schema', 'table_name', 'columns', 'column_types', 'hints', 'table_description', 'column_descriptions', 'column_description'], dtype=str)
                state['catalog'].to_parquet('catalog.parquet', index=False)
            delete_df_button = st.button("Reset", on_click=delete_df, key='delete_df')
            if delete_df_button:
                state['catalog'] = None
                delete_df()
            state['catalog'] = pd.read_parquet('catalog.parquet') if os.path.exists('catalog.parquet') else pd.DataFrame([], columns=['table_catalog', 'table_schema', 'table_name', 'columns', 'column_types', 'hints', 'table_description', 'column_descriptions', 'column_description'], dtype=str)
            st.dataframe(state['catalog'])
        
        with scanned_tab:
            catalogs = query_data("show catalogs")
            input_catalog = st.selectbox("Select Catalog", catalogs, help="Select the catalog to scan.")
            query_data_button = st.button("Scan Catalog")
            if query_data_button:
                listing_catalog = get_catalog_listing(input_catalog)
                state['catalog'] = listing_catalog
                state['catalog'].to_parquet('catalog.parquet', index=False)
            delete_scan_button = st.button("Reset", on_click=delete_df, key='delete_scan')
            if delete_scan_button:
                state['catalog'] = None
                delete_df()
            state['catalog'] = pd.read_parquet('catalog.parquet') if os.path.exists('catalog.parquet') else pd.DataFrame([], columns=['table_catalog', 'table_schema', 'table_name', 'columns'], dtype=str)
            st.dataframe(state['catalog'])
        
    draw_header("Setting", "Cataloging Assistant")
    if 'catalog' in state and state['catalog'] is not None and not state['catalog'].empty:
        catalog = state['catalog']
        if 'table_description' not in catalog.columns:
            catalog['table_description'] = None
        if 'hints' not in catalog.columns:
            catalog['hints'] = None
        if 'column_description' not in catalog.columns:
            catalog['column_description'] = None
        if 'column_descriptions' not in catalog.columns:
            catalog['column_descriptions'] = None

    if 'catalog' in state and state['catalog'] is not None and not state['catalog'].empty:
        catalog = state['catalog']
        total_rows = len(catalog)
        df_view = st.empty()
        if catalog.empty:
            st.error("No catalog to process.")
        else:
            df_view.dataframe(catalog)
        table_processing_header = st.empty()
        two_col_layout = st.columns(2)
        tbl_animation = two_col_layout[0].empty()
        col_animation = two_col_layout[1].empty()
        if st.columns(7)[3].button("Start Processing"):
            for index, row in catalog.iterrows():
                state['progress_bar'].progress((index) / total_rows, f"{index} / {total_rows} processed. {'.'.join([row['table_catalog'], row['table_schema'], row['table_name']])}...")
                try:
                    if row["table_description"]:
                        continue
                    table_processing_header.markdown(f"#### {row['table_catalog']}.{row['table_schema']}.{row['table_name']}")
                    columns = [z for z in remove_consecutive_duplicates([state['re_column'](y.strip()) for y in row['columns'].strip().lstrip('[').rstrip(']').split(',')])[:128] if z and re.sub(r'[^a-zA-Z]', '', z)]
                    columns_with_full_forms = []
                    for column in (columns + [state['re_column'](row['table_name'])]):
                        components = decompose_column_tokens(column)
                        full_forms = match_abbreviations(components)
                        columns_with_full_forms.extend(full_forms)
                    columns_with_full_forms = list(set(columns_with_full_forms))
                    hints = dict(columns_with_full_forms)
                    catalog.at[index, 'hints'] = json.dumps(columns_with_full_forms)
                    with two_col_layout[0]:
                        with st.spinner("Generating table description..."):
                            table_description = generate_table_description(tbl_prompt=state['table_prompt'], table_name=state['re_column'](row['table_name']), columns=columns, hints=hints, md_output=get_markdown_handler(tbl_animation, "", code=False), model_name='neural-chat', timeout=120).strip().rstrip('```').strip()
                    tbl_animation.write(table_description)
                    with two_col_layout[1]:
                        with st.spinner("Generating column description..."):
                            column_descriptions = generate_column_descriptions(column_prompt=state['column_prompt'], table_name=state['re_column'](row['table_name']), columns=columns, hints=hints, table_description=table_description, md_output=get_markdown_handler(col_animation, initial_text="", code=True), model_name='neural-chat', timeout=120).strip().rstrip('```').strip()
                    catalog.at[index, 'column_descriptions'] = column_descriptions

                    with two_col_layout[0]:
                        with st.spinner("Rewriting table description..."):
                            table_description = generate_table_description(tbl_prompt=rewrite_prompt, table_name=state['re_column'](row['table_name']), columns=column_descriptions, md_output=get_markdown_handler(tbl_animation, "", code=False), model_name='neural-chat', timeout=120).strip().rstrip('```').strip()
                    catalog.at[index, 'table_description'] = table_description
                    catalog.at[index, 'column_description'] = parse_column_list(column_descriptions)
                    df_view.dataframe(catalog.explode('column_description'))
                    state['catalog'] = catalog.explode('column_description')
                    catalog.to_parquet('process_file.parquet', index=False)
                except Exception as e:
                    st.error(f"Error processing row {index + 1}: {e}")
                    pass
            state['progress_bar'].progress(1.0, "Processing completed.")

def show():
    steps = sac.steps(
        items=[
            sac.StepsItem(title='Annotate', description='Annotate the warehouse.', icon='file-text'),
            sac.StepsItem(title='Discover', description='Discover ', icon='search'),
        ], 
        return_index=True
    )
    if steps == 0:
        show_cataloging()
    elif steps == 1:
        from .sql_demoable import show as show_sql_demoable
        show_sql_demoable()

# Execute the main function
if __name__ == "__main__":
    show()
