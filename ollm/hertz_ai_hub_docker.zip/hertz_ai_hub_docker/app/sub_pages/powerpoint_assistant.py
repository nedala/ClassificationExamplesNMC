import streamlit as st
from .llm_utils import llm_decorator, get_markdown_handler
import streamlit_antd_components as sac
import pandas as pd
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate

if not 'ppt' in st.session_state:
    st.session_state.ppt = {}
state = st.session_state.ppt

def draw_header(icon, text): return sac.divider(
    label=text, icon=icon, align='center', color='gray')

@llm_decorator()
def generate_pptx(llm, topic, **kwargs):
    template = """You are a great technical writer. Write me ~10 "detailed" slides in JSON format for a presentation on the topic of `{topic}`. Be thorough. Lean towards more inclusion and exhaustive coverage than presuming prior knowledge by the audience. Please include slide_number, title, content (a detailed list of bullets), image_url, code_snippet_to_include, tags (list of keywords), citations (optional 1 or 2 "valid" links), and slide_summary (one sentence) per slide. Be detailed; think step-by-step. The response should be a JSON list of slides along with slides_heading, slide_count fields.
    slides: ```"""
    prompt = ChatPromptTemplate.from_template(template)
    chain = prompt | llm | StrOutputParser()
    return chain.invoke({'topic': topic}).strip().strip('```').strip()


def show():
    st.markdown(f"<h1 style='text-align: center;'>Expert Research Slides</h1>", unsafe_allow_html=True)
    container = st.container()
    entity_box = container.container()
    slide_results = container.container()
    with entity_box:
        textbox = st.text_area('Topic of Interest', "Key differences between GDPR and CAPR", height=150)
        cols = st.columns(7)
        extract_btn = cols[3].button('Generate Slides')
        if extract_btn and textbox:
            slides_view = entity_box.empty()
            entities = generate_pptx(
                textbox, md_output=get_markdown_handler(slides_view, "", code=True))
            slides_view.code(entities)

# Execute the main function
if __name__ == "__main__":
    show()
