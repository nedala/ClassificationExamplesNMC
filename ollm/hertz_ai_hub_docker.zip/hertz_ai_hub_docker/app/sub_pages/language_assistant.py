from collections import defaultdict
import shutil
import streamlit as st
import os
import json
import pandas as pd
import time
from .llm_utils import get_llm, llm_decorator, get_markdown_handler
import streamlit_antd_components as sac
import pandas as pd
import numpy as np
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate

if not 'language' in st.session_state:
    st.session_state.language = {}
state = st.session_state.language

prompt_statement = """You are a helpful assistant strong at multiple languages.
You will translate text from/to English.
You cannot be disrespectful or use offensive words/language.
Kindly ensure the integrity, strength, and intent of the text is maintained in translation. 
End your translated text with triple backticks.
Language: `{language}`
Text: `
{text}
`
Translation: ```
"""


@llm_decorator()
def convert(llm, text, language, **kwargs):
    prompt = ChatPromptTemplate.from_template(prompt_statement)
    chain = prompt | llm | StrOutputParser()
    return chain.invoke({'text': text, 'language':language if language else 'English'}).strip().strip('```').strip()

speech = """I have a dream that one day this nation will rise up and live out the true meaning of its creed: "We hold these truths to be self-evident, that all men are created equal."
I have a dream that my four little children will one day live in a nation where they will not be judged by the color of their skin but by the content of their character.
"""

vande = f"""वंदे मातरम्, वंदे मातरम्!
सुजलाम्, सुफलाम्, मलयज शीतलाम्,
शस्यश्यामलाम्, मातरम्!
वंदे मातरम्!
शुभ्रज्योत्सनाम् पुलकितयामिनीम्,
फुल्लकुसुमित द्रुमदल शोभिनीम्,
सुहासिनीम् सुमधुर भाषिणीम्,
सुखदाम् वरदाम्, मातरम्!
वंदे मातरम्, वंदे मातरम्॥"""

def show():
    st.markdown(f"<h1 style='text-align: center;'>Translation Assistant</h1>",
                unsafe_allow_html=True)
    btns = sac.segmented([sac.SegmentedItem(
        label=idx,) for idx in ['Global', 'English']], align='center')
    if btns == 'English':
        form1 = st.form(key="english_to_global")
        with form1:
            language = st.selectbox(
                label="Select Language",
                options = [
                    "Mandarin Chinese",
                    "Hindi",
                    "Spanish",
                    "French",
                    "Standard Arabic",
                    "Bengali",
                    "Russian",
                    "Portuguese",
                    "Indonesian",
                    "Urdu",
                    "German",
                    "Japanese",
                    "Swahili",
                    "Marathi",
                    "Telugu",
                    "Turkish",
                    "Tamil",
                    "Vietnamese",
                    "Korean"
                ],
                index=2,
            )
            text = st.text_area("Enter text to translate", speech, height=200, max_chars=4096)
            submit = st.columns(9)[4].form_submit_button("Translate")
        if submit:
            with st.spinner("Translating..."):
                message = st.empty()
                translation = convert(text, f'Convert from English to {language}', md_output=get_markdown_handler(message, "", code=False))
                message.code(translation, language='text')
    elif btns == 'Global':
        form2 = st.form(key="global_to_english")
        with form2:
            text = st.text_area("Enter text to translate", vande, height=250, max_chars=4096)
            submit = st.columns(9)[4].form_submit_button("Translate")
        if submit:
            with st.spinner("Translating..."):
                message = st.empty()
                translation = convert(text, f'Convert to English', md_output=get_markdown_handler(message, "", code=False))
                message.code(translation, language='text')

# Execute the main function
if __name__ == "__main__":
    show()
